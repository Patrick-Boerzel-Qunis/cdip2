"""
MatrixMatcher.
Record Linkage framework for internal use at 1&1 Versatel.
"""

# Package info
__title__ = 'MatrixMatcher'
__version__ = 'unknown'
__author__ = 'Jannis.Shadouh@1und1.net'


# Version synonym
try:
    from ._version import __version__
except ModuleNotFoundError:
    print('!! unable to retrieve MatrixMatcher version !!')

# Classes
##############

from .core.matrix import MatrixField, MatchMatrix, MatchCase, Condition
from .core.metrics import MetricWrapper
from .core.indexing import Indexer, Neighborhood
from .regex.name_component import NameFlag, LegalForm
from .core.processing import MatchResults

# Functions
##############

from .main_process import match, slice_dataframe, match_multiprocessing

from .core.metrics.string_comparison import identify_legal_form_in_name, flag_additional_information, \
    is_name_flag_equal, compute_normalized_similarity, apply_metrics

from .core.metrics.metric_delegation import set_external_string_metric

from .core.matrix.default_matrices import get_matrix, show_matrix_list

from .core.processing.id_generation import calculate_tuple_id, calculate_match_id

from .core.processing.job_orchestration import TaskOrchestrator, Task, TaskPool, Worker

from .regex.regex_delegation import identify_legal_form_in_name, extract_legal_forms, \
    get_flag_categories, flag_additional_information

from .utils.system import set_setting, measure_time

# Deprecated function names
# to remove after some time.
###############

# Last Update: 2022/05/03
from .core.metrics.string_comparison import identifyLegalFormInCompanyName, flagAdditionalInformation, \
    isNameFlagEqual, computeNormalizedSimilarity, applyMetrics

# Last Update: 2022/05/03
from .core.matrix.default_matrices import getMatrix, showMatrixList

# Last Update: 2022/05/03
from .regex.regex_delegation import identifyLegalFormInCompanyName, extractLegalForms, \
    getNameFlagCategories, flagAdditionalInformation

# Last Update: 2022/05/03
from .utils.system import setSetting, measureTime
