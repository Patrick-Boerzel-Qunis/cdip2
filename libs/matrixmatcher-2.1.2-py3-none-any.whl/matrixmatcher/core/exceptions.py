"""
Wraps all exception classes.
"""

from typing import List


class MMBaseException(Exception):
    """Base class for MM exceptions"""
    pass


# Default Exceptions
############################

class DtArgumentException(MMBaseException):
    """
    Raised when function argument is of an inapplicable datatype 
    """

    def __init__(self, err_arg: str, expected_dt: str):
        """
        Constructs DtArgumentException.
        
        Keyword Arguments:
        err_arg -- Name of erroneous argument. (type: str)
        expected_dt -- Name of expected datatype. (type: str)
        """
        msg = (
                'Datatype of argument \'' + err_arg
                + '\' is invalid. ( Expected  ' + expected_dt + ' )'
        )

        super().__init__(msg)


class ArgumentNotDefinedException(MMBaseException):
    """
    Raised when a critical function argument is not defined.
    """

    def __init__(self, err_arg: str):
        """
        Constructs ArgumentNotDefinedException.
        
        Keyword Arguments:
        err_arg -- Name of erroneous argument. (type: str)
        """
        msg = (
                'Keyword argument \'' + err_arg
                + '\' is not defined.'
        )

        super().__init__(msg)


class InvalidArgumentException(MMBaseException):
    """
    Raised when an unknown keyword argument is passed to a function.
    """

    def __init__(self, err_arg: str, func_name: str):
        """
        Constructs InvalidArgumentException.

        Keyword Arguments:
        err_arg -- Name of erroneous argument. (type: str)
        func_name -- Name of the corresponding function.
        """
        msg = (
                f'Keyword \'{err_arg}\' is not a valid argument for '
                f'function \'{func_name}\'.'
        )

        super().__init__(msg)


class DtFieldException(MMBaseException):
    """
    Raised when two data fields in input Tables are of different data types.
    """

    def __init__(self, err_field: str, dtype1: str, dtype2: str):
        """
        Constructs DtFieldException.
        
        Keyword Arguments:
        err_field -- Name of erroneous field. (type: str)
        expected_dt -- Name of expected datatype. (type: str)
        """
        msg = (
                'Data types of the field \'' + err_field
                + '\' are differing in input tables. (' + dtype1 + ' and ' + dtype2 + '). ' +
                'Make sure, they are equal to proceed.'
        )

        super().__init__(msg)


class UndefinedFieldTypeException(MMBaseException):
    """
    Raised when entries within an object typed data field are not
    implicitly converted to string type.
    """

    def __init__(self, err_field: str):
        """
        Constructs UndefinedFieldTypeException.

        Keyword Arguments:
        err_field -- Name of erroneous field. (type: str)
        expected_dt -- Name of expected datatype. (type: str)
        """
        msg = (
                'Could not compute similarities on field \'' + err_field
                + '\'. Make sure, all columns are equally typed in both sources to proceed. '
                + '(Avoid object type)'
        )

        super().__init__(msg)


class InputFieldNameException(MMBaseException):
    """
    Raised when input fieldname is unexpected
    """

    def __init__(self, target_obj: str, expected_field: str, input_object: str):
        """
        Constructs InputFieldNameException.
        
        Keyword Arguments:
        target_obj -- Name of object, that takes the input fields. (type: str)
        expected_field -- Name of expected data field. (type: str)
        input_object -- Name of object, that inputs fields into target. (type: str)
        """
        msg = (
                'Object ' + target_obj + ' expected input field \'' + expected_field
                + '\' to be present in object ' + input_object + '.'
        )

        super().__init__(msg)


class ArrayDimensionException(MMBaseException):
    """
    Raised when dimensions of connected arrays are not equal
    """

    def __init__(self, array1: str, array2: str):
        """
        Constructs ArrayDimensionException.
        
        Keyword Arguments:
        target_obj -- Name of object, that takes the input fields. (type: str)
        expected_field -- Name of expected data field. (type: str)
        input_object -- Name of object, that inputs fields into target. (type: str)
        """
        msg = (
                'Dimensions of \'' + array1 + '\' have to be equal to dimensions of \'' + array2 + '\'.'
        )

        super().__init__(msg)


class NumberFormatException(MMBaseException):
    """
    Raised when numbers' formats are unexpected
    """

    def __init__(self, err_arg: str, expected_format: str):
        """
        Constructs NumberFormatException.
        
        Keyword Arguments:
        err_arg -- Name of erroneous argument. (type: str)
        expected_format -- Expected format info. (type: str)
        """
        msg = (
                'Number format of argument \'' + err_arg +
                '\' invalid. ( Expected ' + expected_format + ' )'
        )

        super().__init__(msg)


class InvalidCommandException(MMBaseException):
    """
    Raised when command strings are unexpected
    """

    def __init__(self,
                 err_arg: str,
                 expected_cmd: List[str]):
        """
        Constructs InvalidCommandException.
        
        Keyword Arguments:
        err_arg -- Name of erroneous argument. (type: str)
        expected_cmd -- Expected command options. (type: list<str>)
        """

        msg = (
                'Implementation of argument \'' + err_arg + '\' not found. '
                                                            '( Expected: \'' + '\' OR \''.join(expected_cmd) + '\' )'
        )

        super().__init__(msg)


class SkippedProcessException(MMBaseException):
    """
    Raised when an upstream process has been skipped
    """

    def __init__(self, err_proc: str, skipped_proc: str):
        """
        Constructs SkippedProcessException.
        
        Keyword Arguments:
        err_proc -- Name of failed process. (type: str)
        skipped_proc -- Name of skipped upstream process, that needs to be run. (type: str)
        """
        msg = (
                'Process \'' + err_proc + '\' failed due to missing inputs.\'' + skipped_proc
                + '\' must be run as its upstream process.'
        )

        super().__init__(msg)


class MemoryReferenceException(MMBaseException):
    """
    Raised when two variables, on which concurrent manipulations are performed,
    reference the same object in memory.
    """

    def __init__(self, err_var1: str, err_var2: str):
        """
        Constructs MemoryReferenceException.
        
        Keyword Arguments:
        err_var1 -- Name of erroneous variable 1. (type: str)
        err_var2 --Name of erroneous variable 2. (type: str)
        """
        msg = (
                'Variable \'' + err_var1 + '\' and variable \'' + err_var2
                + '\' reference the same object in memory. ' +
                'The standard matching process requires two objects in memory. ' +
                'Use match_intra() for intra duplicate searches.'
        )

        super().__init__(msg)


class AmbiguousIndexException(MMBaseException):
    """
    Raised when an input table contains duplicated indices.
    """

    def __init__(self, err_var: str):
        """
        Constructs AmbiguousIndexException.
        
        Keyword Arguments:
        err_var1 -- Name of erroneous variable. (type: str)
        """
        msg = (
                'Encountered ambiguous indices in DataFrame \'' + err_var + '\'. '
                + 'Make sure, that all given indices are unique.'
        )

        super().__init__(msg)


class MetricFormatException(MMBaseException):
    """
    Raised when a user defined string metric function is not applicable.
    """

    def __init__(self):
        """
        Constructs MetricFormatException.
        """
        msg = (
                'Encountered inapplicable string metric function. '
                + 'Function must behave like: func(arg1:str, arg2:str) -> float'
        )

        super().__init__(msg)


class SubProcessFailureException(MMBaseException):
    """
    Raised when a subprocess exits with an error code.
    """

    def __init__(self, status_code: str):
        """
        Constructs SubProcessFailureException.
        """
        msg = (
            'Subprocess failed due to an unexpected error. '
            'Exited with status: ' + str(status_code)
        )

        super().__init__(msg)


class TooManyProcessesException(MMBaseException):
    """
    Raised when a more processes are requested than allowed.
    """

    def __init__(self, limit: int):
        """
        Constructs TooManyProcessesException.
        """
        msg = (
            f'Number of requested processes exceeds the limit ({limit}). '
            'Please adjust the number to proceed.'
        )

        super().__init__(msg)


class InvalidMatchCaseException(MMBaseException):
    """
    Raised when a referenced MatchCase 
    column is not present in index.
    """

    def __init__(self):
        """
        Constructs InvalidMatchCaseException.
        """
        msg = (
            'Referenced MatchCase does not exist.'
        )

        super().__init__(msg)


class ResultsComputationException(MMBaseException):
    """
    Raised when the final result table is not
    computable.
    """

    def __init__(self):
        """
        Constructs ResultsComputationException.
        """
        msg = (
            'Could not compute result table. '
            'Make sure, the settings are correct.'
        )

        super().__init__(msg)


class InvalidCombinationException(MMBaseException):
    """
    Raised when a combination of configurations is
    not applicable.
    """

    def __init__(self, setting1: str, setting2: str):
        """
        Constructs InvalidCombinationException.
        """
        msg = (
                'Combination of configurations \'' + setting1 + '\'' +
                ' and \'' + setting2 + '\' is not applicable in this context.'
                + ' (Remove one to proceed).'
        )

        super().__init__(msg)


class JsonFormatException(MMBaseException):
    """
    Raised when a JSON file cannot be parsed to an appropriate object.
    """

    def __init__(self, target_obj: str):
        """
        Constructs JsonFormatException.
        """
        msg = (
                f"Cannot parse JSON to instance of \'{target_obj}\'. "
                "Please check compatibility."
        )

        super().__init__(msg)


class DeserializationException(MMBaseException):
    """
    Raised when a pickle file cannot be deserialized to an appropriate object.
    """

    def __init__(self, target_obj: str):
        """
        Constructs DeserializationException.
        """
        msg = (
                f"Cannot deserialize file to instance of \'{target_obj}\'. "
                "Make sure, that the given file is a valid representation of the object "
                "and check version compatibility."
        )

        super().__init__(msg)
