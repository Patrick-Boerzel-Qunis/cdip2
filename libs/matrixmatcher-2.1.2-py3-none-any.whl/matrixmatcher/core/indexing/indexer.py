"""
Wraps class: Indexer
"""

import math
import time
from typing import List
import pandas as pd
import numpy as np
import warnings

from ..metrics import compute_normalized_similarity
from ..exceptions import DtArgumentException, SkippedProcessException, UndefinedFieldTypeException
from .neighborhood import Neighborhood
from ..matrix import MatrixField
from ..processing import calculate_tuple_id
from ..processing.time_measurement import TimeMeasurement, measurements

warnings.filterwarnings('ignore')


class Indexer:
    """
    Indexer.
    Core object that identifies record tuples to compare.
    """

    def __init__(self,
                 neighborhoods: List[Neighborhood],
                 df1: pd.DataFrame,
                 df2: pd.DataFrame):
        """
        Constructs Indexer object.

        :param df1: input dataFrame 1. All columns, specified in
            the neighborhood(s) must be present in this DataFrame as well.
        :param df2: input dataFrame 2. All columns, specified in
            the neighborhood(s) must be present in this DataFrame as well.
        :param neighborhoods: Sorted neighborhoods with specified sorting
            columns to sort the merged table by. Also containing the size of
            the sliding window, which is the basis for the tuple selection.
        """

        if not isinstance(neighborhoods, list):
            raise DtArgumentException('neighborhood', 'Neighborhood')
        elif not isinstance(df1, pd.DataFrame):
            raise DtArgumentException('df1', 'pd.DataFrame')
        elif not isinstance(df2, pd.DataFrame):
            raise DtArgumentException('df2', 'pd.DataFrame')

        self.neighborhoods = neighborhoods
        self.df1 = df1.copy(deep=True)
        self.df2 = df2.copy(deep=True)
        self.tuples = pd.DataFrame()

    # GETTER
    ##################

    @property
    def neighborhoods(self) -> List[Neighborhood]:
        return self._neighborhoods

    @property
    def df1(self) -> pd.DataFrame:
        return self._df1

    @property
    def df2(self) -> pd.DataFrame:
        return self._df2

    @property
    def tuples(self) -> pd.DataFrame:
        return self._tuples

    # SETTER
    ##################

    @neighborhoods.setter
    def neighborhoods(self, neighborhoods: List[Neighborhood]) -> None:
        self._neighborhoods = neighborhoods

    @df1.setter
    def df1(self, df1: pd.DataFrame) -> None:
        self._df1 = df1

    @df2.setter
    def df2(self, df2: pd.DataFrame) -> None:
        self._df2 = df2

    @tuples.setter
    def tuples(self, tuples: pd.DataFrame) -> None:
        self._tuples = tuples

    # LOGIC
    ##################

    # Standard Indexing: Two differing input tables
    def index(self, thnum: int) -> None:
        """
        Main indexing process. Calculates tuples of potential duplicates.
        Utilizes the attributed df1 and df2 as data sources. The sources are merged
        and sorted via the neighborhoods attribute. To select the tuples, a window
        is slid across the merged table. Inside each window iteration, tuples are
        selected as follows:

        i_df1   |   i_df2
        -------------------
        null        12 _____
        null        87      |
        34 (BASE)   104     | (SL WINDOW t1)
        null        3  _____| ______
        null        578             |
        265 (BASE)  23              | (SL WINDOW t2)
        null        67 _____________|
        null        345

        :param thnum: Identification number of the invoking thread
            for logging purposes.
        """

        start_time = time.perf_counter()

        # Set index columns

        self._df1['index_df1'] = self._df1.index.astype(int)
        self._df2['index_df2'] = self._df2.index.astype(int)

        comparable_tuples = pd.DataFrame()

        for nh in self._neighborhoods:

            # Extract relevant fields

            fields1 = nh.fieldNames + ['index_df1']
            fields2 = nh.fieldNames + ['index_df2']

            # Fusion and sorting of input frames based on neighborhood.

            fusion = pd.concat(
                [self._df1[fields1], self._df2[fields2]],
                axis=0
            )

            fusion_sorted = fusion.sort_values(by=nh.fieldNames)
            fusion_sorted.reset_index(drop=True, inplace=True)
            fusion_sorted['index_fu'] = fusion_sorted.index

            # Prepare theoretical tuples
            #################################

            # Initialize tuples for all windows
            tuples_wnd = []

            # Indices of smaller input frame are the bases for each window:
            #
            #  i_df1   |   i_df2
            #  -------------------
            #  null        12 _____
            #  null        87      |
            #  34 (BASE)   104     | (SL WINDOW t1)
            #  null        3  _____| ______
            #  null        578             |
            #  265 (BASE)  23              | (SL WINDOW t2)
            #  null        67 _____________|
            #  null        345

            base_indices = (
                fusion_sorted.loc[~fusion_sorted['index_df1'].isnull()]['index_fu']
                if self._df1.shape[0] < self._df2.shape[0] else
                fusion_sorted.loc[~fusion_sorted['index_df2'].isnull()]['index_fu']
            ).values

            wsize_half = int((nh.windowSize - 1) / 2)

            # Warning: Adjust this tolerance value with care!
            # Excessive tolerances can lead to an increase in
            # False negative rates.
            max_dist_tolerance = wsize_half/4

            # Initial value
            bi_pre = math.inf

            for b in range(len(base_indices)):

                bi = base_indices[b]

                # Only calculate window, if last calculated
                # base index is not too close. (Optimizes performance)
                if abs(bi-bi_pre) > max_dist_tolerance:

                    # Set the current base index as the last
                    # successfully calculated window
                    bi_pre = bi

                    # Indices of fusion inside the current window (b is center)
                    # (This method only works with odd window sizes)
                    window_indices = list(
                        range((bi - wsize_half), (bi + wsize_half)+1)
                    )

                    # Calculate tuples for current window and add to the list
                    for i in window_indices:
                        for j in window_indices:
                            if j >= i:
                                tuples_wnd.append([i, j])

            # Extract unique tuples (intersections between windows exist)
            tuples_wnd = np.unique(tuples_wnd, axis=0)

            # Writing tuples to target frame and split tuples into
            # single indices.
            tuples_df = pd.DataFrame(
                data={'i_fu1': tuples_wnd[:, 0],
                      'i_fu2': tuples_wnd[:, 1]}
            )

            tuples_df[:] = tuples_df[:].astype(int)

            # Convert theoretical into concrete tuples
            # (indices of fusion to indices of df1 and df2)
            #################################

            fusion_lookup = fusion_sorted[
                ['index_df1', 'index_df2', 'index_fu']
            ]

            translated_tuples = tuples_df.merge(
                fusion_lookup.rename(columns={'index_fu': 'i_fu1'}),
                on='i_fu1',
                how='left'
            ).rename(
                columns={
                    'index_df1': 'index_df1_fu1',
                    'index_df2': 'index_df2_fu1'
                }
            ).merge(
                fusion_lookup.rename(columns={'index_fu': 'i_fu2'}),
                on='i_fu2',
                how='left'
            ).rename(
                columns={
                    'index_df1': 'index_df1_fu2',
                    'index_df2': 'index_df2_fu2'
                }
            )[
                [
                    'index_df1_fu1',
                    'index_df2_fu1',
                    'index_df1_fu2',
                    'index_df2_fu2'
                ]
            ]

            comparable_tuples_nh = translated_tuples.loc[
                (~translated_tuples['index_df1_fu1'].isnull() &
                 ~translated_tuples['index_df2_fu2'].isnull()) |
                (~translated_tuples['index_df2_fu1'].isnull() &
                 ~translated_tuples['index_df1_fu2'].isnull())
            ]

            comparable_tuples = pd.concat(
                [comparable_tuples, comparable_tuples_nh],
                axis=0
            ).drop_duplicates()

        # Processing comparable tuples
        #################################

        comparable_tuples.insert(
            len(comparable_tuples.columns),
            'df1',
            np.nan
        )

        comparable_tuples.insert(
            len(comparable_tuples.columns),
            'df2',
            np.nan
        )

        for df in ["df1", "df2"]:
            for fu in ["fu1", "fu2"]:
                comparable_tuples.loc[
                    ~comparable_tuples[f"index_{df}_{fu}"].isnull(), df
                ] = (
                    comparable_tuples.loc[
                        ~comparable_tuples[f"index_{df}_{fu}"].isnull()
                    ][f"index_{df}_{fu}"]
                )

        # Write result to class attribute
        self.tuples = comparable_tuples[['df1', 'df2']]

        # For logging
        measurements.append_values(
            start=start_time,
            label="index"
        )

    def index_intra(self, thnum: int) -> None:
        """
        Indexing process for intra matching: Calculation of record tuples of
        potential duplicates for one input table. This method wraps the main
        indexing method in order to remove (i,i) tuples as well as each (i,j)
        tuple for every corresponding (j,i) tuple.

        :param thnum: Identification number of the invoking thread
            for logging purposes.
        """

        # Standard indexing
        self.index(thnum)

        start_time = time.perf_counter()

        # Drop (i,i) tuples
        self._tuples = self._tuples.loc[
            self._tuples['df1'] != self._tuples['df2']
        ]

        # Drop every (i,j) tuple for each (j,i) tuple
        #################################

        # Set index columns
        self._tuples.reset_index(drop=True, inplace=True)
        self._tuples['index'] = self._tuples.index

        # Helper. Only temporary
        tuples = pd.DataFrame()

        # tuple_ID to pandas.Series
        tuples['tuples'] = calculate_tuple_id(
            self._tuples["df1"],
            self._tuples["df2"]
        )

        # convert (j,i) to (i,j) tuple_IDs
        tuples['tuples_flipped'] = calculate_tuple_id(
            self._tuples["df2"],
            self._tuples["df1"]
        )

        tuples['index'] = tuples.index

        # Merge (i,j) with (j,i)
        merge = tuples.merge(
            tuples, left_on='tuples',
            right_on='tuples_flipped',
            how='left'
        )

        # Identify unique (j,i) tuples. Drop all
        # corresponding (i,j) tuples with higher indices
        unique_tuple_indices = merge.loc[
            merge['index_y'].isnull() |
            (merge['index_x'] < merge['index_y'])
            ]['index_x']

        # Write results
        self.tuples = self._tuples.loc[
            self._tuples['index'].isin(unique_tuple_indices)
        ].drop(columns={'index'})

        # For logging
        measurements.append_values(
            start=start_time,
            label="index_intra"
        )

    def compare_field_by_field(self,
                               matrix_field: MatrixField,
                               thnum: int = 0,
                               exclude: List[str] = None) -> pd.DataFrame:
        """
        Compares each of the indexer's tuples on a given field,
        based on defined metrics to calculate string similarities.
        This method only works on an indexer object, that has been initialized with tuples
        by calling its index() or index_intra() method.

        :param matrix_field: MatrixField object to run the string comparison on. The field name of
            this object has to be present in the indexer's df1 and df2 attributes.
        :param thnum: Identification number of the current thread.
            Main purpose is for logging.
        :param exclude: List of tuple_IDs of structure "<df1>_<df2>" to exclude from the calculation.
            If None, all tuples a compared.
        :return: DataFrame, containing the appropriate tuple indices (df1, df2) as well as the tuple_ID
            for each compared tuple. The column with name "<fieldname>_<method>" contains the
            concrete similarity values for each tuple calculated on the provided field.
        """

        if not isinstance(self.tuples, pd.DataFrame):
            raise SkippedProcessException('Indexer.compare()', 'Indexer.index()')

        # Prepare input data
        #################################

        df1_f = self.df1[[matrix_field.fieldname]]
        df2_f = self.df2[[matrix_field.fieldname]]

        df1_f['df1'] = df1_f.index
        df2_f['df2'] = df2_f.index

        # Only cast explicitly to string, if fields are not object type.
        # The main process already ensures data type equality for all fields within the sources.
        if (
            df1_f.iloc[:, 0].dtype != np.dtype('object') and
            df2_f.iloc[:, 0].dtype != np.dtype('object')
        ):
            df1_f.iloc[:, 0] = df1_f.iloc[:, 0].astype(str)
            df2_f.iloc[:, 0] = df2_f.iloc[:, 0].astype(str)

        selection = self.tuples.merge(
            df1_f, on='df1', how='left'
        ).merge(
            df2_f, on='df2', how='left'
        )

        selection["tuple_ID"] = calculate_tuple_id(
            selection["df1"], selection["df2"]
        )

        # Ignore excluded tuples
        if exclude is not None:
            selection = selection.loc[
                ~selection["tuple_ID"].isin(exclude)
            ]

        # Calculate similarities
        #################################

        features = selection[["df1", "df2", "tuple_ID"]]

        # message_out(
        #     f"Calculating similarities for field \'{matrix_field.fieldname}\'.",
        #     str(thnum)
        # )

        feature_col = matrix_field.get_feature_column()
        features.insert(0, feature_col, np.nan)

        if features.shape[0] > 0:
            try:
                features[feature_col] = selection.apply(
                    lambda x: compute_normalized_similarity(
                        x[matrix_field.fieldname + '_x'],
                        x[matrix_field.fieldname + '_y'],
                        matrix_field.method,
                        use_name_flags=matrix_field.use_name_flags,
                        cmp_legal_forms=matrix_field.cmp_legal_forms,
                        ign_legal_forms=matrix_field.ign_legal_forms,
                        reinit_metrics=False
                    ),
                    axis=1
                )
            except DtArgumentException:
                raise UndefinedFieldTypeException(matrix_field.fieldname)

        return features
