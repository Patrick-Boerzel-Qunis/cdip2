"""
Wraps class: Neighborhood
"""

from typing import List

from ..exceptions import DtArgumentException, NumberFormatException


class Neighborhood:
    """
    Contains sorting information and the
    size of the sliding window.
    """

    def __init__(self,
                 fieldNames: List[str],
                 windowSize: int = 21):
        """
        Constructs Neighborhood object.

        :param fieldNames: Names of the data fields to sort the input data by. The chosen
            names must be present (exact) in the input DataFrames of the main process.
            The naming of those fields has to be consistent with the MatrixFields
            used within the MatchMatrix. Note: The ordering of the passed list is important.
            The first element of the list is the primary sorting criteria.
        :param windowSize: Size of the sliding window used for indexing. This number has to
            be chosen with care: Large windows cause longer runtimes and excessive memory
            usage; Small windows can potentially lead to a higher false negative rate.
            Check the documentation for further information on the matter.
            (The window size must be an odd integer number)
        """

        if not isinstance(fieldNames, list):
            raise DtArgumentException('fieldNames', 'list<str>')
        elif not isinstance(windowSize, int):
            raise DtArgumentException('windowSize', 'int')
        elif windowSize % 2 == 0:
            raise NumberFormatException('windowSize', 'ODD int')

        self.fieldNames = fieldNames
        self.windowSize = windowSize

    # GETTER
    ##################

    @property
    def fieldNames(self) -> List[str]:
        return self._fieldNames

    @property
    def windowSize(self) -> int:
        return self._windowSize

    # SETTER
    ##################

    @fieldNames.setter
    def fieldNames(self, fieldNames: List[str]) -> None:
        self._fieldNames = fieldNames

    @windowSize.setter
    def windowSize(self, windowSize: int) -> None:
        self._windowSize = windowSize
