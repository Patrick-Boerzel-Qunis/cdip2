"""
Wraps class: Condition
"""

from ..exceptions import DtArgumentException, InvalidCommandException


class Condition:
    """
    Condition. Defines a condition within a MatchCase
    to be compared in the matching process.
    """

    def __init__(self,
                 value: float,
                 option: str):
        """
        Constructs Condition object.

        :param value: Threshold similarity value above which to accept matches.
            This value is highly dependent on the utilized similarity measure and
            should always be set with care. See the documentation for further
            information on the matter.
        :param option: Comparison option, that controls how the process handles missing data.
            Available options are '+', '-' or '*':
            '+': Both field values must be filled to accept the condition as fulfilled.
            '-': One or both field values must be filled to accept the condition as fulfilled.
            '*': Both field values must either be filled or empty to accept the condition as
                fulfilled.
        """

        if not isinstance(value, float):
            raise DtArgumentException('value', 'float')
        elif not isinstance(option, str):
            raise DtArgumentException('option', 'str')

        self.id = 'NO_ID'  # Default id
        self.value = value
        self.option = option

    # GETTER
    ##################

    @property
    def id(self) -> str:
        return self._id

    @property
    def option(self) -> str:
        return self._option

    @property
    def value(self) -> int:
        return self._value

    # SETTER
    ##################

    @id.setter
    def id(self, id: str) -> None:
        self._id = id

    @option.setter
    def option(self, option: str) -> None:

        if not isinstance(option, str):
            raise DtArgumentException('option', 'str')
        elif option not in ['+', '-', '*']:
            raise InvalidCommandException(
                'option', ['+', '-', '*']
            )

        self._option = option

    @value.setter
    def value(self, value: int) -> None:
        if 0.0 <= value <= 1.0:
            self._value = value
        else:
            raise DtArgumentException("value", "float in [0,1]")
