"""
Contains all Default matrices
"""
from typing import List

from .match_case import MatchCase
from .match_matrix import MatchMatrix
from .matrix_field import MatrixField
from ..exceptions import InvalidCommandException
from ...utils import deprecation_warning_alias


def show_matrix_list() -> List[str]:
    """
    Lists all implemented default matrices' labels by which
    to address a specific matrix.
    """
    return [matrix.label for matrix in DEFAULT_MATR]


def get_matrix(label: str) -> MatchMatrix:
    """
    Retrieve a particular MatchMatrix from the defaults,
    based on a specified unique label.

    :param label: Unique label of the chosen matrix.
        Use show_matrix_list() to show all available labels.
    :return: Retrieved MatchMatrix object.
    """
    try:
        match_matrix = [
            matrix for matrix in DEFAULT_MATR if matrix.label == label
        ][0]
    except IndexError:
        raise InvalidCommandException(
            "label", show_matrix_list()
        )

    return match_matrix


# Implementations
######################

name_address = MatchMatrix(
    fields=[
        MatrixField(fieldName='Firmenname', method='worddiff',
                    use_name_flags=True, cmp_legal_forms=True),
        MatrixField(fieldName='Strasse', method='worddiff'),
        MatrixField(fieldName='Hausnummer', method='housenumber'),
        MatrixField(fieldName='PLZ', method='identity'),
        MatrixField(fieldName='Ort', method='worddiff')
    ],
    cases=[
        MatchCase([1.00, 0.99, 1.00, 1.00, 1.00], ['+', '+', '-', '+', '+']),
        MatchCase([0.95, 0.99, 0.99, 1.00, 0.80], ['+', '+', '-', '+', '+']),
        MatchCase([0.92, 0.98, 0.98, 1.00, 0.90], ['+', '+', '-', '+', '+']),
        MatchCase([0.90, 0.97, 0.94, 1.00, 0.75], ['+', '+', '-', '+', '+']),
        MatchCase([0.92, 0.84, 0.94, 1.00, 0.72], ['+', '+', '-', '+', '+']),
        MatchCase([0.86, 0.94, 0.94, 1.00, 0.72], ['+', '+', '-', '+', '+']),
        MatchCase([0.80, 0.88, 0.94, 1.00, 0.72], ['+', '+', '-', '+', '+'])
    ],
    label='Firmenname_Adresse'
)

name_address_weak = MatchMatrix(
    fields=[
        MatrixField(fieldName='Firmenname', method='worddiff',
                    use_name_flags=False, ign_legal_forms=True),
        MatrixField(fieldName='Strasse', method='worddiff'),
        MatrixField(fieldName='Hausnummer', method='housenumber'),
        MatrixField(fieldName='PLZ', method='identity'),
        MatrixField(fieldName='Ort', method='worddiff')
    ],
    cases=[
        MatchCase([1.00, 0.99, 1.00, 1.00, 1.00], ['+', '+', '-', '+', '+']),
        MatchCase([0.95, 0.99, 0.99, 1.00, 0.80], ['+', '+', '-', '+', '+']),
        MatchCase([0.92, 0.98, 0.98, 1.00, 0.90], ['+', '+', '-', '+', '+']),
        MatchCase([0.90, 0.97, 0.94, 1.00, 0.75], ['+', '+', '-', '+', '+']),
        MatchCase([0.92, 0.84, 0.94, 1.00, 0.72], ['+', '+', '-', '+', '+']),
        MatchCase([0.86, 0.94, 0.94, 1.00, 0.72], ['+', '+', '-', '+', '+']),
        MatchCase([0.80, 0.88, 0.94, 1.00, 0.72], ['+', '+', '-', '+', '+'])
    ],
    label='Firmenname_Adresse_weich'
)

address_only = MatchMatrix(
    fields=[
        MatrixField(fieldName='Strasse', method='worddiff_locality', performance_priority=3),
        MatrixField(fieldName='Hausnummer', method='housenumber', performance_priority=0),
        MatrixField(fieldName='PLZ', method='identity', performance_priority=1),
        MatrixField(fieldName='Ort', method='worddiff_locality', performance_priority=2)
    ],
    cases=[
        MatchCase([0.99, 0.99, 1.00, 1.00], ['+', '-', '+', '+']),
        MatchCase([0.97, 0.99, 1.00, 0.95], ['+', '-', '+', '+']),
        MatchCase([0.94, 0.98, 1.00, 0.90], ['+', '-', '+', '+']),
        MatchCase([0.90, 0.94, 1.00, 0.85], ['+', '-', '+', '+']),
        MatchCase([0.84, 0.94, 1.00, 0.85], ['+', '-', '+', '+']),

    ],
    label='Adresse_allein'
)


########################
# CONSOLIDATION
########################

DEFAULT_MATR = [
    name_address,
    name_address_weak,
    address_only
]


#############
# DEPRECATION
#############

@deprecation_warning_alias("get_matrix")
def getMatrix(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'get_matrix'.
    """
    return get_matrix(*args, **kwargs)


@deprecation_warning_alias("show_matrix_list")
def showMatrixList():
    """
    Deprecated function name.
    Please refer to name 'show_matrix_list'.
    """
    return show_matrix_list()
