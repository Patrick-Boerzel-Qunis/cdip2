"""
Wraps class: MatchCase
"""

from copy import copy
from typing import List

from ..exceptions import DtArgumentException, ArrayDimensionException
from .condition import Condition


class MatchCase:
    """
    MatchCase. Defines a case within a MatchMatrix
    to be compared in the matching process. Collects and constructs conditions.
    """

    def __init__(self,
                 condition_vals: List[float],
                 options: List[str]):
        """
        Constructs MatchCase object and hereby also constructs the
        Condition objects, owned by this MatchCase.

        :param condition_vals: List of threshold similarity values above which to accept matches.
            Those values are highly dependent on the utilized similarity measures and
            should always be set with care. See the documentation for further
            information on the matter.
        :param options: List of comparison options, that control how the process handles missing data.
            Available options are '+', '-' or '*':
            '+': Both field values must be filled to accept the condition as fulfilled.
            '-': One or both field values must be filled to accept the condition as fulfilled.
            '*': Both field values must either be filled or empty to accept the condition as
                fulfilled.
        """

        if (not isinstance(condition_vals, list)) or \
                (not isinstance(condition_vals[0], float)):
            raise DtArgumentException('conditionVals', 'list<float>')
        elif (not isinstance(options, list)) or \
                (not isinstance(options[0], str)):
            raise DtArgumentException('options', 'list<str>')

        self.id = 'NO_ID'  # Default id
        self.conditions = self.generate_conditions(condition_vals, options)

    # GETTER
    ##################

    @property
    def id(self) -> str:
        return self._id

    @property
    def conditions(self) -> List[Condition]:
        return self._conditions

    # SETTER
    ##################

    @id.setter
    def id(self, id) -> None:
        self._id = id

    @conditions.setter
    def conditions(self, conditions: List[Condition]) -> None:
        self._conditions = conditions

    # LOGIC
    ##################

    def get_condition_ids(self) -> List[str]:
        """
        Returns the ids of all Condition objects,
        owned by this MatchCase
        """
        condIds = []
        for cond in self._conditions:
            condIds = condIds + [cond.id]
        return condIds

    @staticmethod
    def generate_conditions(condition_vals: List[float],
                            options: List[str]) -> List[Condition]:
        """
        Generates condition objects from equally sorted and equally sized lists of
        condition values and corresponding condition options.

        :param condition_vals: List of threshold similarity values above which to accept matches.
            Those values are highly dependent on the utilized similarity measures and
            should always be set with care. See the documentation for further
            information on the matter.
        :param options: List of comparison options, that control how the process handles missing data.
            Available options are '+', '-' or '*':
            '+': Both field values must be filled to accept the condition as fulfilled.
            '-': One or both field values must be filled to accept the condition as fulfilled.
            '*': Both field values must either be filled or empty to accept the condition as
                fulfilled.
        :return: List of all generated Condition objects.
        """

        conditions = []

        if len(options) == len(condition_vals):
            for c in range(len(condition_vals)):
                conditions = conditions + [Condition(condition_vals[c], options[c])]
        else:
            raise ArrayDimensionException(
                'conditionVals', 'options'
            )

        return conditions

    def copy(self):
        """
        Copies the MatchCase instance and all of its Condition objects.
        """
        cpy = copy(self)
        cpy.conditions = [copy(cond) for cond in cpy.conditions]
        return cpy
