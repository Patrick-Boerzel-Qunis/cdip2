"""
Wraps class: MatchMatrix
"""
from copy import copy
from typing import List
import json

from .matrix_field import MatrixField
from .match_case import MatchCase
from ..exceptions import DtArgumentException, ArrayDimensionException, \
    JsonFormatException, InvalidCommandException
from ...utils import deprecation_warning_alias, deprecation_warning_deletion


class MatchMatrix:
    """
    Core object that hosts all relevant matching preferences and provides
    a decision model for the interpretation of duplicates.
    """

    def __init__(self,
                 fields: List[MatrixField],
                 cases: List[MatchCase],
                 label: str = '?Matrix?'):
        """
        Constructs MatchMatrix object.

        :param fields: List of relevant fields and comparison methods
            as MatrixField objects. These fields are compared
            for each record tuple within the main process.
        :param cases: List of relevant MatchCase objects, that define the decision model.
            If at least one of the provided MatchCases hits i.e. all the contained
            Conditions are fulfilled for a record tuple, the tuple is assumed to be a match.
        :param label: Optional unique label for persistence purposes. The label does
            not affect the matching process in any way.
        """

        if (not isinstance(fields, list)) and (not isinstance(fields[0], MatrixField)):
            raise DtArgumentException('fields', 'list<MatrixField>')
        elif (not isinstance(cases, list)) and (not isinstance(cases[0], MatchCase)):
            raise DtArgumentException('cases', 'list<MatrixCase>')

        self.fields = [copy(field) for field in fields]
        self.cases = [case.copy() for case in cases]
        self.label = label

        # Setting defaults
        # THIS IS A LEGACY ATTRIBUTE. ONLY USE UNTIL set_setting METHOD IS REMOVED.
        self._settings = {
            'parallel_processing': {'threads': 1, 'slicesize': -1}
        }

    def __eq__(self, other):
        return self.label == other.label

    # GETTER
    ##################

    @property
    def cases(self) -> List[MatchCase]:
        return self._cases

    @property
    def fields(self) -> List[MatrixField]:
        return self._fields

    @property
    def label(self) -> str:
        return self._label

    @property
    def settings(self) -> dict:
        return self._settings

    # SETTER
    ##################

    @cases.setter
    def cases(self, cases: List[MatchCase]) -> None:
        for c in range(len(cases)):

            # Set Case Id
            cases[c].id = 'case_' + str(c)

            # Check dimensions
            if len(cases[c].conditions) != len(self._fields):
                raise ArrayDimensionException('conditions', 'fields')

            # Set condition Ids
            for v in range(len(cases[c].conditions)):
                cases[c].conditions[v].id = 'cond_' + str(c) + '_' + str(v)

        self._cases = cases

    @fields.setter
    def fields(self, fields: List[MatrixField]) -> None:
        self._fields = fields

    @label.setter
    def label(self, label: str) -> None:
        self._label = label

    @settings.setter
    def settings(self, settings: dict) -> None:
        self._settings = settings

    # Additional Getters
    ##################

    def get_case_ids(self) -> List[str]:
        """Returns all ids of the matrix's MatchCase objects."""
        return [
            case.id for case in self.cases
        ]

    def get_field_names(self) -> List[str]:
        """Returns all names of matrix's MatrixField objects."""
        return [
            mxf.fieldname for mxf in self.fields
        ]

    def get_feature_columns(self) -> List[str]:
        """Returns all labels of the matrix's feature columns"""
        return [
            mxf.get_feature_column() for mxf in self.fields
        ]

    def get_comparison_methods(self) -> List[str]:
        """
        Returns all string comparison methods of matrix's
        MatrixField objects.
        """
        return [
            mxf.method for mxf in self.fields
        ]

    # Additional setters
    ##################

    @deprecation_warning_deletion(
        "Please use the keyword argument \'threading_settings\' "
        "of the main process function \'match\' instead."
    )
    def set_setting(self,
                    setting: str,
                    definition: object) -> None:
        """
        Sets additional matching settings, that can impact
        the main process dramatically. All settings have to be chosen with care.
        Please check the documentation for further information.

        :param setting: Unique label of the setting.
        :param definition: Setting's values (value is dependent on the chosen setting).

        Currently, available combinations are:
            setting = 'parallel_processing': Enables the use of multiple
                threads in the main process.
            definition = {'threads': x, 'slicesize': y}: Performs the main process
                with x threads and processes the smaller of the two input DataFrames
                (or the first one, if size does not differ) in chunks of y records per thread.
        """

        if setting == 'parallel_processing':
            try:
                if isinstance(definition, dict):
                    if (definition['threads'] > 0) and (definition['slicesize'] > 0):
                        self.settings['parallel_processing'] = definition
                    else:
                        raise Exception()
                else:
                    raise Exception()
            except Exception:
                raise DtArgumentException(
                    'parallel_processing',
                    'dict (Usage: {\'threads\'>0, \'slicesize\'>0})'
                )
        else:
            raise InvalidCommandException("setting", ["parallel_processing"])

    # Additional Features
    ##################

    def profile(self) -> None:
        """Prints a human-readable profile of the matrix."""
        print(self.to_string())

    def update(self,
               case: dict = None,
               field: dict = None) -> None:
        """
        Updates the MatchMatrix on the chosen attributes. MatchCases and
        MatrixFields can be updated together in one call. However, you can only update
        one of each at a time.

        :param case: Dictionary containing updated MatchCase data.
            example: {"index": 2, "field": "Street", "value": 0.96}
        :param field: Dictionary containing updated MatrixField data.
            example: {"name": "Street", "method": "worddiff", use_name_flags=True,
                        cmp_legal_forms=False, ign_legal_forms=True}
        """

        # Check for illegal keys
        valid_keys_case = ["index", "field", "value", "option"]
        valid_keys_field = ["name", "method", "use_name_flags",
                            "cmp_legal_forms", "ign_legal_forms"]

        # MatchCase update
        if case is not None:
            if not all(key in valid_keys_case for key in case.keys()):
                raise InvalidCommandException("case", valid_keys_case)

            if case.get("index", None) is not None and case.get("field", None) is not None and \
                    (case.get("option", None) is not None or case.get("value", None) is not None):

                try:
                    field_index = [
                        i for i in range(len(self.fields)) if
                        self.fields[i].fieldname == case.get("field")
                    ][0]
                except IndexError:
                    raise InvalidCommandException("field", self.get_field_names())

                try:
                    if case.get("value", None) is not None:
                        self.cases[case.get("index")].conditions[
                            field_index].value = case.get("value")

                    if case.get("option", None) is not None:
                        self.cases[case.get("index")].conditions[
                            field_index].option = case.get("option")

                except IndexError:
                    raise InvalidCommandException(
                        "index", [str(i) for i in range(len(self.cases))]
                    )

        # MatrixField update
        if field is not None:
            if not all(key in valid_keys_field for key in field.keys()):
                raise InvalidCommandException("field", valid_keys_field)

            if field.get("name", None) is not None:
                try:
                    field_index = [
                        i for i in range(len(self.fields))
                        if self.fields[i].fieldname == field.get("name")
                    ][0]

                    if field.get("method", None) is not None:
                        self.fields[field_index].method = field.get("method")
                    if field.get("use_name_flags", None) is not None:
                        self.fields[field_index].use_name_flags = field.get("use_name_flags")
                    if field.get("cmp_legal_forms", None) is not None:
                        self.fields[field_index].cmp_legal_forms = field.get("cmp_legal_forms")
                    if field.get("ign_legal_forms", None) is not None:
                        self.fields[field_index].ign_legal_forms = field.get("ign_legal_forms")

                except IndexError:
                    raise InvalidCommandException("name", self.get_field_names())

    # Conversions
    ##################

    def to_json(self, path: str) -> None:
        """
        Serializes the MatchMatrix object into a JSON file.

        :param path: Path to the file.
        """

        json_dump = json.dumps(
            self,
            default=lambda x: x.__dict__,
            sort_keys=True,
            indent=4
        )

        with open(path, 'w') as file:
            file.write(json_dump)

    @staticmethod
    def from_json(path: str):
        """
        Parses a MatchMatrix instance from a compatible JSON object.

        :param path: Path to compatible JSON file.
        :return: Parsed MatchMatrix object.
        """

        with open(path) as json_file:
            json_matrix = json.loads(json_file.read())

        try:
            return MatchMatrix(
                fields=[
                    MatrixField(
                        fieldName=field["_fieldname"],
                        method=field["_method"],
                        use_name_flags=field["_use_name_flags"],
                        cmp_legal_forms=field["_cmp_legal_forms"],
                        ign_legal_forms=field["_ign_legal_forms"],
                    ) for field in json_matrix["_fields"]
                ],
                cases=[
                    MatchCase(
                        condition_vals=[
                            cond["_value"] for cond in case["_conditions"]
                        ],
                        options=[
                            cond["_option"] for cond in case["_conditions"]
                        ]
                    ) for case in json_matrix["_cases"]
                ],
                label=json_matrix["_label"]
            )
        except KeyError:
            raise JsonFormatException("MatchMatrix")

    def to_string(self) -> str:
        """
        Converts MatchCases and Conditions of this
        matrix into a presentable string.

        :return: String representation of the MatchMatrix.
        """

        # Default settings
        offset = 10
        spaces = 3
        min_width = 9
        sep_char = '-'

        # calculate column widths
        col_widths = [0] + [
            (
                len(f.fieldname) + spaces
                if len(f.fieldname) + spaces >= min_width else
                min_width + spaces
            ) for f in self.fields
        ]

        # Init separator line
        str_out = (sep_char * spaces).join(
            [sep_char * w for w in col_widths]
        ) + '\n'

        # Prepare header line
        str_out = str_out + ' ' * offset

        # Header line
        for f in range(len(self.fields)):
            f_name = self.fields[f].fieldname
            f_name_pre = self.fields[f - 1].fieldname

            str_out = (
                    str_out + ' ' * (col_widths[f] - len(f_name_pre)) + f_name
            )

        str_out = str_out + '\n\n'

        # Add Cases and conditions
        for case in self.cases:

            prefix = case.id + ': '

            str_out = str_out + prefix + ' ' * (offset - len(prefix))

            for f in range(len(self._fields)):
                c = case.conditions[f]
                cell_text = "%.2f" % c.value + ' (' + c.option + ')'

                str_out = (
                        str_out + ' ' * (col_widths[f] - len(cell_text)) + cell_text
                )

            str_out = str_out + '\n'

        str_out = str_out + '\n'

        # Add MatrixFields
        for field in self._fields:
            str_out = (
                    str_out +
                    'Field: \'' + field.fieldname + '\', Metric: ' +
                    field.method +
                    (', use_name_flags='+str(field.use_name_flags) if field.use_name_flags else '') +
                    (', cmp_legal_forms=True' if field.cmp_legal_forms else '') +
                    (', ign_legal_forms=True' if field.ign_legal_forms else '') + '\n'
            )

        # Add last separator line
        str_out = str_out + (sep_char * spaces).join(
            [sep_char * w for w in col_widths]
        ) + '\n'

        return str_out

    #############
    # DEPRECATION
    #############

    @deprecation_warning_alias("set_setting")
    def setSetting(self, *args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'set_setting'.
        """
        return self.set_setting(*args, **kwargs)

    @deprecation_warning_alias("to_json")
    def toJson(self, *args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'to_json'.
        """
        return self.to_json(*args, **kwargs)

    @deprecation_warning_alias("from_json")
    def fromJson(*args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'from_json'.
        """
        return MatchMatrix.from_json(*args, **kwargs)
