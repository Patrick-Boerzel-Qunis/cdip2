"""
Wraps class: MatrixField
"""

from ..exceptions import InvalidCommandException
from ..metrics.metric_delegation import get_wrapped_metrics
from ...regex.regex_delegation import get_flag_categories


class MatrixField:
    """
    Defines a data field
    to be compared in the matching process.
    """

    def __init__(self,
                 fieldName: str,
                 method: str,
                 use_name_flags: object = False,
                 cmp_legal_forms=False,
                 ign_legal_forms=False,
                 performance_priority: int = 100):
        """
        Constructs MatrixField object.

        :param fieldName: Name of the chosen data field in the input table(s). This name
            must be present in the input DataFrames AND must be consistent with the
            naming of fields in the Neighborhood objects.
        :param method: Label of the string similarity metric to use for the
            comparison of values in this field. Use core.get_wrapped_metrics()
            to get a complete list of all the available string metrics.
        :param ign_legal_forms: Shall legal forms be extracted and removed from string to
            boost the string comparison metric? The legal form is removed from the company
            name before the metric calculation for this field. (Only applicable on company names)
            E.g.: "ABC GmbH" -> "ABC" -> calculation...
        :param cmp_legal_forms: Are legal forms to be extracted and compared? The legal form
            is extracted into a separate field and compared, if present in both records
            of one tuple. (Only applicable on company names)
        :param use_name_flags: Are name-flags to be used for this field? Set to True to select all
            available categories or choose specific categories. The specific categories can vary
            throughout the implementations. Use RegexDelegator.get_flag_categories() to get a
            complete list of all available categories.
            E.g.: True or {'NLB'}.
        :param performance_priority: Which priority shall this field have in the
            main process's similarity calculation? Lower priority values are
            calculated first. If a field is easy and fast to calculate, consider
            a lower value. If it needs a lot of computation, consider a higher value.
        """

        self.fieldname = fieldName
        self.method = method
        self.use_name_flags = use_name_flags
        self.cmp_legal_forms = cmp_legal_forms
        self.ign_legal_forms = ign_legal_forms
        self.performance_priority = performance_priority

    def __lt__(self, other):
        return self.performance_priority < other.performance_priority

    def __gt__(self, other):
        return self.performance_priority > other.performance_priority

    def __eq__(self, other):
        return (self.performance_priority == other.performance_priority) and \
               (self.fieldname == other.fieldname)

    # GETTER
    ##################

    @property
    def fieldname(self) -> str:
        return self._fieldname

    @property
    def use_name_flags(self) -> [set, bool]:
        return self._use_name_flags

    @property
    def cmp_legal_forms(self) -> bool:
        return self._cmp_legal_forms

    @property
    def ign_legal_forms(self) -> bool:
        return self._ign_legal_forms

    @property
    def method(self) -> str:
        return self._method

    @property
    def performance_priority(self) -> int:
        return self._performance_priority

    # SETTER
    ##################

    @fieldname.setter
    def fieldname(self, fieldName: str) -> None:
        self._fieldname = fieldName

    @method.setter
    def method(self, method: str) -> None:
        if method not in get_wrapped_metrics():
            raise InvalidCommandException(
                'method',
                get_wrapped_metrics()
            )
        self._method = method

    @use_name_flags.setter
    def use_name_flags(self, use_name_flags: [set, bool]) -> None:
        if not isinstance(use_name_flags, bool):
            if not all([cat in get_flag_categories() for cat in use_name_flags]):
                raise InvalidCommandException(
                    "use_name_flags",
                    list(get_flag_categories()) + ["bool"]
                )
        self._use_name_flags = use_name_flags

    @cmp_legal_forms.setter
    def cmp_legal_forms(self, cmp_legal_forms: bool) -> None:
        self._cmp_legal_forms = cmp_legal_forms

    @ign_legal_forms.setter
    def ign_legal_forms(self, ign_legal_forms: bool) -> None:
        self._ign_legal_forms = ign_legal_forms

    @performance_priority.setter
    def performance_priority(self, performance_priority) -> None:
        self._performance_priority = performance_priority

    # LOGIC
    ###############

    def get_feature_column(self) -> str:
        """
        Returns the label of the corresponding column
        in the features DataFrame.
        """
        return self.fieldname + '_' + self.method
