"""
Contains the wrapping of string metrics and the
delegation of the calls to specific metrics.
"""

from typing import List
import textdistance as dist

from .string_metrics import get_cascading, get_housenumber_metric, \
    get_identity, get_soren_dice, get_worddiff, get_worddiff_locality
from .metric_wrapper import MetricWrapper
from ..exceptions import MetricFormatException, InvalidCommandException
from ...utils import deprecation_warning_alias

# Declaration of globals
_wrappers = []
_isInitialized = False
_addedMetrics = []


def init_wrapper_delegation(reinit: bool) -> None:
    """
    Initializes all metric wrappers. This is an essential step to
    make the metrics globally available. The initialization has to
    be conducted on all changes to any of the string metrics.

    :param reinit: Shall the initialization be repeated,
        if it already has been conducted? Only activate, if metrics
        have been changed or added during runtime.
    """

    global _wrappers
    global _isInitialized
    global _addedMetrics

    if (not _isInitialized) or reinit:
        _wrappers = []

        _wrappers.extend(
            [MetricWrapper(get_cascading, 'cascading'),
             MetricWrapper(get_housenumber_metric, 'housenumber'),
             MetricWrapper(get_identity, 'identity'),
             MetricWrapper(dist.jaro_winkler.normalized_similarity, 'jarowinkler'),
             MetricWrapper(dist.editex.normalized_similarity, 'phon_editex'),
             MetricWrapper(dist.damerau_levenshtein.normalized_similarity, 'dameraulevenshtein'),
             MetricWrapper(get_soren_dice, 'sorensen_dice'),
             MetricWrapper(get_worddiff, 'worddiff'),
             MetricWrapper(get_worddiff_locality, "worddiff_locality")] + _addedMetrics
        )

        _isInitialized = True


def setExternalMetricWrapper(wrapper: MetricWrapper) -> None:
    """
    Adds an external (custom) metric wrapper to the collection
    and reinitializes the wrapper collection.

    :param wrapper: External metric wrapper to add to
        collection.
    """

    global _addedMetrics

    if wrapper not in _addedMetrics:
        _addedMetrics.append(wrapper)
    else:  # Overwrite
        _addedMetrics.remove(wrapper)
        _addedMetrics.append(wrapper)

    init_wrapper_delegation(True)


def set_external_string_metric(func: callable, label: str) -> None:
    """
    Adds an external string similarity metric to the collection.
    After adding the metric, it is globally available to use in all
    MatrixMatcher processes via the specified label. However, the
    metric is not persistent across python kernels.

    :param func: Function, defining metric logic. The function exactly takes
        two positional string arguments and returns a float similarity
        value between 0.0 and 1.0. Example:
        metric_x(str1: str, str2: str) -> float
    :param label: Unique metric label, that identifies the metric globally.
    """

    try:
        if func.__code__.co_argcount == 2:
            val = func('', '')
            if isinstance(val, float) or isinstance(val, int):
                setExternalMetricWrapper(MetricWrapper(func, label))
            else:
                raise TypeError()
        else:
            raise AttributeError()
    except (TypeError, AttributeError):
        raise MetricFormatException()


def delegateWrapper(label: str, *args, **kwargs) -> float:
    """
    Delegates a call to a specified MetricWrapper via the
    chosen unique metric label.

    :param label: Unique metric label, that identifies the
        chosen MetricWrapper object.
    :param args: Positional arguments passed to the
        MetricWrapper object.
    :param kwargs: Keyword arguments passed to the
        MetricWrapper object.
    :return: Float similarity value, returned by the specified
        MetricWarpper's logic function.
    """

    global _wrappers

    for wr in _wrappers:
        if wr.label == label:
            return wr.invoke(*args, **kwargs)


def get_wrapped_metrics() -> List[str]:
    """
    Returns all implemented string comparison methods as labels.
    Returns list of strings.

    :return: Complete list of all unique labels of the implemented
        string similarity metrics at the time of invocation.
    """

    init_wrapper_delegation(False)
    global _wrappers

    labels = []
    for wr in _wrappers:
        labels.append(wr.label)

    return labels


def get_metric_wrapper(label: str) -> MetricWrapper:
    """
    Returns an implemented MetricWrapper object by its label.

    :param label: String label of the MetricWrapper to get.
        Check get_wrapped_metrics() for all implemented metrics.
    :return: Specified MetricWrapper object.
    """

    try:
        return [wr for wr in _wrappers if wr.label == label][0]
    except IndexError:
        raise InvalidCommandException("label", get_wrapped_metrics())


#############
# DEPRECATION
#############

@deprecation_warning_alias("init_wrapper_delegation")
def initWrapperDelegation(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'init_wrapper_delegation'.
    """
    return init_wrapper_delegation(*args, **kwargs)


@deprecation_warning_alias("get_wrapped_metrics")
def getWrappedMetrics():
    """
    Deprecated function name.
    Please refer to name 'get_wrapped_metrics'.
    """
    return get_wrapped_metrics()


@deprecation_warning_alias("set_external_string_metric")
def setExternalStringMetric(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'set_external_string_metric'.
    """
    return set_external_string_metric(*args, **kwargs)


@deprecation_warning_alias("get_metric_wrapper")
def getMetricWrapper(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'get_metric_wrapper'.
    """
    return get_metric_wrapper(*args, **kwargs)
