"""
Wraps class: MetricWrapper
"""


class MetricWrapper:
    """
    Defines an object, that wraps a specified
    string comparison metric function.
    """

    def __init__(self, func: callable, label: str):
        """
        Constructs MetricWrapper object.

        :param func: Function, defining metric logic. The function exactly takes
            two positional string arguments and returns a float
            similarity value between 0.0 and 1.0. Example:
            metric_x(str1: str, str2: str) -> float
        :param label: Unique metric label, that identifies the metric globally.
        """
        self.func = func
        self.label = label

    def __eq__(self, other):
        return self._label == other.label

    def __hash__(self):
        return hash(self._label)

    # GETTER
    ##################

    @property
    def func(self) -> callable:
        return self._func

    @property
    def label(self) -> str:
        return self._label

    # SETTER
    ##################

    @func.setter
    def func(self, func: callable) -> None:
        self._func = func

    @label.setter
    def label(self, label: str) -> None:
        self._label = label

    # LOGIC
    ##################

    def invoke(self, *args, **kwargs):
        """
        Invokes the logic function, with passed arguments.

        :param args: Positional arguments passed to the wrapper object.
        :param kwargs: Keyword arguments passed to the wrapper object.
        :return: Output of the logic function.
        """

        out = self.func(*args, **kwargs)
        return out
