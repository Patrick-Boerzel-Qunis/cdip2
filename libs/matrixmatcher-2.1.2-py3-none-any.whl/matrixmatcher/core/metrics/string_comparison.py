"""
Contains all relevant functions for string comparison.
"""

from typing import List
import numpy as np
import pandas as pd

from ...regex.regex_delegation import flag_additional_information, identify_legal_form_in_name
from ...utils.string_standardization import normalize_unicode_characters, standardize_umlauts
from ...utils.system import deprecation_warning_alias, get_setting

from ..exceptions import InvalidCommandException, DtArgumentException
from .metric_delegation import init_wrapper_delegation, delegateWrapper, get_wrapped_metrics


def compute_normalized_similarity(str1: str,
                                  str2: str,
                                  method: str,
                                  use_name_flags: object = False,
                                  ign_legal_forms: bool = False,
                                  cmp_legal_forms: bool = False,
                                  reinit_metrics=False) -> float:
    """
    Calculates the normalized similarity measure between two input string values
    for with a chosen calculation method.The function delegates method calls from
    the main process to the appropriate calculation methods.

    :param str1: input string 1.
    :param str2: input string 2.
    :param method: Label of the string similarity metric to use for the
        comparison of the input strings. Use core.get_wrapped_metrics()
        to get a complete list of all the available string metrics.
    :param ign_legal_forms: Shall legal forms be extracted and removed from string to
        boost the string comparison metric? The legal form is removed from the company
        name before the metric calculation for this calculation. (Only applicable on
        company names). E.g.: "ABC GmbH" -> "ABC" -> calculation...
    :param cmp_legal_forms: Are legal forms to be extracted and compared? The legal form
        is extracted into a separate field and compared, if present in both input strings.
        (Only applicable on company names)
    :param use_name_flags: Are name-flags to be used for this calculation? Set to True to
        select all available categories or choose specific categories. The specific
        categories can vary throughout the implementations. Use
        RegexDelegator.get_flag_categories() to get a complete list of all
        available categories.
    :param reinit_metrics: Shall the metric initialization be repeated,
        if one initialization has already been conducted? Only activate if specifically
        needed. For example, if new string metrics are added during the
        main process's runtime.
    :return: Normalized similarity between string1 and string2 as a
        float value from 0.0 to 1.0.
    """

    # Only allow calculation if input strings are not null or empty
    if (not empty_or_null(str1)) and (not empty_or_null(str2)):

        if not isinstance(str1, str) or not isinstance(str2, str):
            raise DtArgumentException("str1/str2", "str")

        # Standardize string
        [str1, str2] = [str1.lower().strip(),
                        str2.lower().strip()]

        [str1, str2] = [standardize_umlauts(str1),
                        standardize_umlauts(str2)]

        [str1, str2] = [normalize_unicode_characters(str1),
                        normalize_unicode_characters(str2)]

        # Only apply following standardization if legal form needed

        lf1, lf2 = None, None

        if ign_legal_forms or cmp_legal_forms:

            lf_ex1, lf_ex2 = [identify_legal_form_in_name(str1),
                              identify_legal_form_in_name(str2)]

            str1, str2 = lf_ex1[0], lf_ex2[0]
            lf1, lf2 = lf_ex1[1], lf_ex2[1]

        # Apply name-flag configurations.
        name_flags_equal = True
        if isinstance(use_name_flags, bool) and use_name_flags:
            name_flags_equal = is_name_flag_equal(str1, str2)
        elif isinstance(use_name_flags, set):
            name_flags_equal = is_name_flag_equal(str1, str2, use_name_flags)

        # Only allow calculation if name flags are equal. If use_name_flags is set to True
        if ((use_name_flags and name_flags_equal)
                or
                (not use_name_flags)):

            # Only allow calculation if legal forms are equal. If use_legal_forms is set to True
            if ((cmp_legal_forms and (lf1 == lf2 or lf1 == 'NoF' or lf2 == 'NoF'))
                    or
                    (not cmp_legal_forms)):

                init_wrapper_delegation(reinit_metrics)

                if method in get_wrapped_metrics():

                    return delegateWrapper(
                        method,
                        str1,
                        str2
                    )

                else:
                    raise InvalidCommandException(
                        'method = ' + '\'' + method + '\'',
                        get_wrapped_metrics()
                    )

            else:  # Legal forms are not equal and use_legal_forms is set to True
                return 0.0

        else:  # Name flags are not equal and use_name_flags is set to True
            return 0.0

    elif empty_or_null(str1) and empty_or_null(str2):
        return -2  # Marker: Both values are null

    elif empty_or_null(str1) or empty_or_null(str2):
        return -1  # Marker: One value is null


# HELPERS
########################

def is_name_flag_equal(str1: str,
                       str2: str,
                       category: set = None) -> bool:
    """
    Identifies and compares the name flags of two company names.

    :param str1: String company name 1.
    :param str2: String company name 2.
    :param category: Selected name flag categories.Set to True to select
        all available categories or choose specific categories. The specific
        categories can vary throughout the implementations. Use
        RegexDelegator.get_flag_categories() to get a complete list of all
        available categories.
    :return: True, if all name flags are equal and False, if at least one
        name flag is interpreted differently.
    """

    flags1 = flag_additional_information(str1, category)
    flags2 = flag_additional_information(str2, category)

    return np.all([flags1[k] == flags2[k] for k in flags1])


def apply_metrics(metrics: List[str],
                  ser1: pd.Series,
                  ser2: pd.Series,
                  use_name_flags: bool = False,
                  cmp_legal_forms: bool = False,
                  ign_legal_forms: bool = False) -> pd.DataFrame:
    """
    Applies all given metrics to the input data (comparison between strings
    with same index in the two input Series objects) and inserts a new column
    for each metric.

    :param metrics: List of labels of the string similarity metrics to use for the
        calculations. Use core.get_wrapped_metrics() to get a complete
        list of all the available string metrics.
    :param ser1: Input series of strings.
    :param ser2: Input series of strings.
    :param ign_legal_forms: Shall legal forms be extracted and removed from string to
        boost the string comparison metric? The legal form is removed from the company
        name before the metric calculation for this calculation. (Only applicable on
        company names). E.g.: "ABC GmbH" -> "ABC" -> calculation...
    :param cmp_legal_forms: Are legal forms to be extracted and compared? The legal form
        is extracted into a separate field and compared, if present in both input strings.
        (Only applicable on company names)
    :param use_name_flags: Are name-flags to be used for this calculation? Set to True to
        select all available categories or choose specific categories. The specific
        categories can vary throughout the implementations. Use
        RegexDelegator.get_flag_categories() to get a complete list of all
        available categories.
    :return: pandas.DataFrame containing the input strings and the concrete similarities
        in each row.
    """

    if ser1.shape[0] != ser2.shape[0]:
        raise Exception('Input data\'s dimensions must align.')

    ser1 = ser1.reset_index(drop=True)
    ser2 = ser2.reset_index(drop=True)

    out = pd.DataFrame(
        {'sample1': ser1, 'sample2': ser2}
    )

    for metric in metrics:
        out[metric] = out.apply(
            lambda x: compute_normalized_similarity(
                x['sample1'], x['sample2'],
                method=metric,
                use_name_flags=use_name_flags,
                cmp_legal_forms=cmp_legal_forms,
                ign_legal_forms=ign_legal_forms
            ), axis=1
        )

    return out


##############
# EVALUATIONS
##############

# noinspection PyBroadException
def empty_or_null(str_: str) -> bool:
    """
    Evaluates the contents of a string value and
    identifies empty or null values.

    :param str_: input string to evaluate.
    :return: True, if the string is empty or null;
        False, if it is not.
    """

    try:
        isNan = np.isnan(str_)
    except Exception:
        isNan = False

    try:
        str_ = str_.replace(' ', '')
    except AttributeError:
        ...

    return ((str_ is None) |
            isNan |
            (str_ == '') |
            (str_ == 'None') |
            (str_ == 'none') |
            (str_ == 'NaN') |
            (str_ == 'nan'))


#############
# DEPRECATION
#############

@deprecation_warning_alias("identify_legal_form_in_name")
def identifyLegalFormInCompanyName(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'identify_legal_form_in_name'.
    """
    return identify_legal_form_in_name(*args, **kwargs)


@deprecation_warning_alias("flag_additional_information")
def flagAdditionalInformation(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'flag_additional_information'.
    """
    return flag_additional_information(*args, **kwargs)


@deprecation_warning_alias("is_name_flag_equal")
def isNameFlagEqual(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'is_name_flag_equal'.
    """
    return is_name_flag_equal(*args, **kwargs)


@deprecation_warning_alias("compute_normalized_similarity")
def computeNormalizedSimilarity(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'compute_normalized_similarity'.
    """
    return compute_normalized_similarity(*args, **kwargs)


@deprecation_warning_alias("apply_metrics")
def applyMetrics(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'apply_metrics'.
    """
    return apply_metrics(*args, **kwargs)
