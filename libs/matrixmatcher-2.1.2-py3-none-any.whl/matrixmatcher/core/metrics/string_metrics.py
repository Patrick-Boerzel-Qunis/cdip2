"""
Contains all internally implemented string
similarity metrics.
"""

import re
from typing import List
import textdistance as dist
import math

from ...utils.string_standardization import remove_separator_characters


##################
# IMPLEMENTATIONS
##################

def get_ngrams(str_: str, n: int = 2) -> List[str]:
    """
    Splits a given input string into grams of length n.
    Example: "Testing" (n=3) -> ['Tes', 'est', 'sti', 'tin', 'ing']

    :param str_: Input string to split into n-grams.
    :param n: Length of each n-gram. The length should never exceed the
        length of the string.
    :return: List of n-grams.
    """

    ngrams = [
        "" for _ in range(len(str_) - (n - 1))
    ]

    for i in range(len(str_) - n + 1):
        ngrams[i] = str_[i:i + n]
    return ngrams


def get_soren_dice(str1: str, str2: str) -> float:
    """
    Computes the normalized Sorensen-Dice similarity
    between two input strings.

    :param str1: Input string 1
    :param str2: Input string 2
    :return: Normalized Sorensen-Dice similarity [0,1]
    """

    # Setting #
    n = 2
    ###########

    [ng1, ng2] = [get_ngrams(str1, n),
                  get_ngrams(str2, n)]

    matches = set.intersection(set(ng1), set(ng2))
    total = len(set(ng1)) + len(set(ng2))

    return (
        0.0
        if 0 == total else
        2 * len(matches) / total
    )


def get_worddiff(str1: str,
                 str2: str,
                 sord_cutoff: float = 0.85,
                 sord_max_rel_len_devi: float = 0.20,
                 cos_zero_weight: float = 1.85,
                 match_partially: bool = True) -> float:
    """
    Returns the Word-Difference similarity between two
    input strings. For further information, check the documentation.

    :param str1: Input string 1
    :param str2: Input string 2
    :param sord_cutoff: Cutoff value for the word-by-word
        Sorensen-Dice comparison. 85% proves to be the best value for
        company names and German locality names.
    :param sord_max_rel_len_devi: Maximum relative length deviation between two words,
        to qualify for the word-by-word comparison.
    :param cos_zero_weight: Coefficient in the final cosine error function,
        that impacts the slope and thus the progression of penalties for each
        word difference.
    :param match_partially: If true, the partial matching of one word,
        containing the other, is possible if both words are longer than 4 characters.
        This proves to be an advantage for the comparison of company names and a
        disadvantage for the comparison of locality names.
    :return: Normalized Word-Difference similarity [0,1]
    """

    # Performance boost
    if str1 == str2:
        return 1.0

    # Remove special characters

    special_chars = [
        ',', ';', '/', '\\', '-', '|', '.', '&', '+', '@',
        '"', '*', '(', ')', '_', '[', ']'
    ]

    for char in special_chars:
        [str1, str2] = [str1.replace(char, ' '), str2.replace(char, ' ')]

    # Remove consecutive and leading/tailing whitespaces
    [str1, str2] = [
        re.sub(r"\s+", " ", str1.strip()),
        re.sub(r"\s+", " ", str2.strip())
    ]

    # Performance enhancement
    if str1 == '' or str2 == '':
        return 0.0

    # Split into words
    [split1, split2] = [str1.split(' '),
                        str2.split(' ')]

    # Remove duplicated words
    split1 = list(set(split1))
    split2 = list(set(split2))

    # Check for equivalence regardless of word permutations
    if set(split1) == set(split2):
        return 1.0

    # Find matches word by word
    ##########

    wo_match = 0
    match_penalty = 0

    for word_1 in split1:
        for word_2 in split2:

            rel_len = len(word_1) / len(word_2)

            # Performance enhancement: 
            # Only compare words w/ similar lengths
            if (1 - sord_max_rel_len_devi) < rel_len < (1 + sord_max_rel_len_devi):

                # Compare words that could potentially match
                wo_sim = get_soren_dice(word_1, word_2)
                if wo_sim > sord_cutoff:
                    wo_match += 1

            # One word contains the other: Match partially
            elif match_partially and ((len(word_1) >= 5 and len(word_2) >= 5)
                                      and (word_1 in word_2 or word_2 in word_1)):
                wo_match += 1

                # Calculate penalty for partial match
                match_penalty += (1 - (len(word_1) / len(word_2))
                                  if len(word_1) < len(word_2) else
                                  1 - (len(word_2) / len(word_1)))

    # Evaluate results
    ##########

    # If no matching words present: return soren-dice.
    if wo_match == 0:
        return get_soren_dice(str1, str2)

    # Determine differences 
    # Assumption: Differences between strings 
    # contain the highest information density.
    wo_diff = len(split1) + len(split2) - 2*wo_match

    len_diff = abs(len(split1) - len(split2)) / 2

    # Return the normalized similarity based on the defined error function
    return math.cos(
        (math.pi * (wo_diff + match_penalty))
        /
        (cos_zero_weight * (len(split1) + len(split2) + len_diff))
    )


def get_worddiff_locality(str1: str, str2: str) -> float:
    """
    Returns the Word-Difference similarity (for German locality names)
    between two input strings. For further information, check
    the documentation.

    :param str1: Input string 1
    :param str2: Input string 2
    :return: Normalized Word-Difference (locality) similarity [0,1]
    """

    def standardize(string: str):
        string = re.sub(
            pattern=" ([Aa](n|m)|a\\.) ?(der |d\\.)? ?",
            repl=" ",
            string=string
        )

        string = re.sub(
            pattern="[Ss]tra(ß|ss)e",
            repl="str",
            string=string
        )

        return string

    return get_worddiff(
        standardize(str1),
        standardize(str2),
        match_partially=False
    )


def get_cascading(str1: str, str2: str) -> float:
    """
    Returns normalized Cascading similarity for two input strings.
    For further information, check the documentation.

    :param str1: Input string 1
    :param str2: Input string 2
    :return: Normalized Cascading similarity [0,1]
    """

    return (
           dist.jaro_winkler.normalized_similarity(str1, str2) +
           dist.sorensen_dice.normalized_similarity(str1, str2)
           ) / 2


def get_housenumber_metric(str1: str, str2: str) -> float:
    """
    Similarity metric for the comparison of house numbers
    and house number ranges. Returns normalized similarity.

    :param str1: Input string 1
    :param str2: Input string 2
    :return: Normalized Housenumber similarity [0,1]
    """

    [str1, str2] = [str1.replace(' ', ''),
                    str2.replace(' ', '')]

    # Case: Complete match (format is irrelevant)
    if str1 == str2:
        return 1.0

    # Case: House number ranges
    if is_numeric_range(str1) or is_numeric_range(str2):  # Ranges exist

        split1, split2 = str1.split('-'), str2.split('-')

        if is_numeric_range(str1) and is_numeric_range(str2):  # Two ranges exist
            try:
                if is_equivalent_range(split1, split2):  # Two ranges are equal (including flipped ranges)
                    return 1.0
                else:
                    return 0.0
            except ValueError:
                return get_cascading(str1, str2)  # If no other case matches: Choose Cascading

        elif ((is_numeric_range(str1) and not is_numeric_range(str2)) or
              (not is_numeric_range(str1) and is_numeric_range(str2))):  # One range and one single number

            range_ = (
                split1
                if len(split1) == 2 else
                split2
            )

            solo = (
                split1[0]
                if len(split1) == 1 else
                split2[0]
            )

            try:
                if int(solo) in [int(num) for num in range_]:
                    return 1.0
                else:
                    return 0.0
            except ValueError:
                return get_cascading(str1, str2)  # If no other case matches: Choose Cascading

    else:  # No ranges exist

        # Case: Two single numbers with affixes
        try:
            int(str1) + int(str2)  # No affixes found
            return 0.0
        except ValueError:  # Affixes found in at least one house number

            char_error, num_error = False, False
            num1, num2 = -1, -1
            chars1, chars2 = "", ""

            try:
                chars1 = re.search('\\D+', str1).group(0).strip()
                chars2 = re.search('\\D+', str2).group(0).strip()
            except AttributeError:
                char_error = True

            try:
                num1 = re.search('\\d*', str1).group(0).strip()
                num2 = re.search('\\d*', str2).group(0).strip()
            except AttributeError:
                num_error = True

            if num1 == num2 and not char_error and not num_error:
                chars1 = remove_separator_characters(chars1)
                chars2 = remove_separator_characters(chars2)
                return get_cascading(chars1, chars2)

            else:  # Numbers not equal
                return 0.0


def get_identity(str1: str, str2: str) -> float:
    """
    Similarity metric for the exact comparison of two input strings.

    :param str1: Input string 1
    :param str2: Input string 2
    :return: Normalized Identity similarity [0,1]
    """

    return 1.0 if str1 == str2 else 0.0


########################
# HELPER EVALUATIONS
########################

def is_numeric_range(range_: str) -> bool:
    """
    Is a given string a representation of a numeric range
    with structure x-y?

    :pram range_: String to be evaluated.
    :return: True, if the string represents a numeric range;
        False, if it does not.
    """
    split = range_.split('-')

    if len(split) == 2:
        try:
            int(split[0].strip()) + int(split[1].strip())
            return True
        except ValueError:
            ...

    return False


def is_equivalent_range(range1: List[str], range2: List[str]) -> bool:
    """
    Is a given house number range equivalent to another one?
    Ranges are assumed equivalent, if at least one number is present in both
    ranges.

    :param range1: List of two integers in string representation.
    :param range2: List of two integers in string representation.
    :return: True, if the ranges are equivalent; False, if they are not.
    """

    range1_set = {int(val) for val in range1}
    range2_set = {int(val) for val in range2}

    return len(range1_set.intersection(range2_set)) >= 1
