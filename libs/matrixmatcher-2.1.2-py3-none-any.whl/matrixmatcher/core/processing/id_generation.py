"""
Contains functions to calculate the
match_ID and tuple_ID.
"""

import pandas as pd
import networkx as nx
import numpy as np

from ..exceptions import ArrayDimensionException


def calculate_tuple_id(index_df1: pd.Series,
                       index_df2: pd.Series) -> pd.Series:
    """
    Calculates the tuple_ID for a given index combination.
    Both input series must have the same lengths.

    :param index_df1: Series of indices (float or int) of
        the first input DataFrame. (left side of record tuple)
    :param index_df2: Series of indices (float or int) of
        the second input DataFrame. (right side of record tuple)
    :return: Series of tuple_IDs.
    """

    if index_df1.shape[0] != index_df1.shape[0]:
        raise ArrayDimensionException("index_df1", "index_df2")

    return (
        index_df1.astype(int).astype(str) +
        '_' +
        index_df2.astype(int).astype(str)
    )


def calculate_match_id(index_df1: pd.Series,
                       index_df2: pd.Series,
                       is_intra: bool = False) -> pd.Series:
    """
    Calculates ids for each duplicate group of
    matched record tuples based on a given index combination,
    using a network based approach and inserts the id as a
    new column "match_ID".

    The resulting id can create chains over multiple MatchCases.
    Hence, weaker MatchCases can influence stronger ones.

    E.g.: 12_35 (matched via MatchCase 0) +
            16_35 (matched via MatchCase 3) +
                16_47 (matched via MatchCase 0)

    :param index_df1: Series of indices (float or int) of
        the first input DataFrame. (left side of record tuple)
    :param index_df2: Series of indices (float or int) of
        the second input DataFrame. (right side of record tuple)
    :param is_intra: Do both sides of the given tuples have the same
        source DataFrame?
    :return: Series of match_IDs.
    """

    indices = pd.DataFrame()

    if index_df1.shape[0] != index_df1.shape[0]:
        raise ArrayDimensionException("index_df1", "index_df2")

    # Set suffixes in index columns (to identify source frame)
    indices['df1_node'] = index_df1.astype(str) + ('' if is_intra else '_1')
    indices['df2_node'] = index_df2.astype(str) + ('' if is_intra else '_2')

    # Set network's edges to index nodes
    edges = list(
        indices.itertuples(index=False, name=None)
    )

    # Set indices
    indices['df1'] = index_df1
    indices['df2'] = index_df2

    # Initialize match_ID column
    indices.insert(0, 'match_ID', np.nan)

    # Generate graph
    g = nx.Graph(edges)

    # Return groups
    groups = list(
        nx.connected_components(g)
    )

    # Extract duplicate group IDs and write into matches frame
    id_curr = 0
    for gr in groups:
        id_curr += 1

        for index in gr:

            if not is_intra:

                df_number = index.split('_')[1]
                i = index.split('_')[0]

                indices["match_ID"] = np.where(
                    indices[f'df{str(df_number)}'] == int(float(i)),
                    str(int(id_curr)),
                    indices["match_ID"]
                )

            elif is_intra:

                i = index
                for df_number in [1, 2]:
                    indices["match_ID"] = np.where(
                        indices[f'df{str(df_number)}'] == int(float(i)),
                        str(int(id_curr)),
                        indices["match_ID"]
                    )

    return indices['match_ID']
