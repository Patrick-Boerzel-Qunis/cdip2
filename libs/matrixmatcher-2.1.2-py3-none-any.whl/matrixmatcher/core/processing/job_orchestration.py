"""
Wraps classes:
"""

from copy import copy
from threading import Thread
from typing import List
import time

from ..exceptions import DtArgumentException


class Task(Thread):
    """
    Task thread to execute within a TaskPool. This class contains additional methods
    to support the execution through Worker objects.
    """
    def __init__(self, func: callable, arguments: list):
        """
        Constructs Task object.

        :param func: Function, defining the task's contents. This function must
            comply with the signature: func(worker_ident: int, **kwargs, *args) -> any.
            Where worker_ident describes the identification number of the owning Worker instance.
        :param arguments: Positional arguments to pass to the task during execution.
        """
        super().__init__(target=func, args=arguments, daemon=True)
        self.returnable: any = None
        self.worker_ident: int = -1
        self.exception: [BaseException, None] = None
        self.processing_state: str = ["AVAILABLE", "TAKEN", "DONE", "FAILED"][0]

    def take(self, worker_ident: int) -> None:
        """
        Sets the task's processing state to TAKEN, which signals an
        ongoing execution through a worker.

        :param worker_ident: Identification number of the owning Worker instance.
        """
        self.processing_state = "TAKEN"
        self.worker_ident = worker_ident

    def complete(self) -> None:
        """
        Sets the processing state to DONE, which signals the
        task's successful completion. This method does not override
        a FAILED processing state.
        """
        if self.processing_state != "FAILED":
            self.processing_state = "DONE"

    def fail(self, ex: BaseException) -> None:
        """
        Sets the processing state to FAILED, which signals any type
        of exception during the task's execution.
        """
        self.processing_state = "FAILED"
        self.exception = ex

    def join(self, *args) -> None:
        """
        Wait for the task thread to join the main thread. Once the
        thread joined, the task is marked as completed.
        """
        super().join(timeout=10**6)
        self.complete()

    # noinspection PyUnresolvedReferences
    def run(self) -> None:
        """
        Runs the task's function with the task's arguments and
        exception handling. First positional argument is always
        the worker identification number. The function's returns are
        passed to the task's returnable attribute.
        """
        try:
            if self._target is not None:
                self.returnable = self._target(
                    self.worker_ident,
                    *self._args,
                    **self._kwargs
                )
        except Exception as ex:
            self.fail(ex)

    def is_available(self) -> bool:
        """
        Returns true, if processing state is AVAILABLE i.e.
        ready for processing.
        """
        return self.processing_state == "AVAILABLE"

    def is_failed(self) -> bool:
        """
        Returns true, if the current task encountered an exception.
        """
        return self.processing_state == "FAILED"


class TaskPool(list):
    """
    Collection of an arbitrary number of Task instances. This
    class provides additional methods to support the tasks' execution.
    """

    def __init__(self, *args):
        """
        Constructs TaskPool object.

        :param args: Task instances to add to the pool.
        """
        if all([isinstance(arg, Task) for arg in args]) or len(args) == 0:
            super().__init__([copy(task) for task in args])

    def next(self) -> [Task, None]:
        """
        Returns the next available task. If no task is
        available, the method returns None.
        """
        try:
            return [task for task in self if task.is_available()][0]
        except IndexError:
            return

    def has_next(self):
        """
        Returns true, if the pool contains available tasks.
        """
        return len([task for task in self if task.is_available()]) > 0

    def get_completed_count(self):
        """
        Returns the current number of completed tasks within the pool.
        """
        return len([task for task in self if task.processing_state == "DONE"])

    def append(self, task: Task) -> None:
        """
        Appends a specified Task instance to the end of the pool.

        :param task: Task instance to append
        """
        if isinstance(task, Task):
            super().append(task)
        else:
            raise DtArgumentException("task", "Task")


class Worker:
    """
    Worker, that acts as a wrapper within Task instances can be executed
    sequentially.
    """

    def __init__(self, ident: int = -1):
        """
        Constructs Worker object.

        :param ident: Identification number of the worker instance.
            This number is passed down into the tasks to use for logging purposes.
        """
        self.task: [Task, None] = None
        self.ident = ident

    def run_task(self, task: Task) -> None:
        """
        Runs the passed task thread and marks it as "TAKEN" to signal
        its execution. If the worker is busy, the task is rejected (return w/o action).

        :param task: Task instance to take and run.
        """

        if task is None:
            return

        if not self.is_busy():
            self.check_and_raise()
            task.take(self.ident)
            self.task = task
            self.task.start()

    def check_and_raise(self):
        """
        Checks whether the current task (if available) encountered an
        exception and raises it.
        """
        if self.task is not None and self.task.is_failed():
            raise self.task.exception

    def join_task(self):
        """
        Waits for the task thread to join the main thread. If the
        worker is not busy, the method returns without action.
        """
        if self.is_busy():
            self.task.join()
            self.check_and_raise()

    def is_busy(self) -> bool:
        """
        Evaluates whether the worker is busy or not. It is assumed busy, if
        it possesses a running task thread. If the worker possesses a task thread,
        that has ended its execution, the task is marked as completed.
        """
        if self.task is not None:
            if self.task.is_alive():
                return True
            else:
                self.task.complete()
        return False


class TaskOrchestrator:
    """
    Contains the execution logic for the processing of a given task pool
    through a specified number of parallel task threads.
    """

    def __init__(self, task_pool: TaskPool, thread_count: int):
        """
        Constructs TaskOrchestrator object.

        :param task_pool: TaskPool instance containing the tasks to process.
        :param thread_count: Number of parallel task threads to use for
            processing.
        """
        self.task_pool = task_pool
        self.workers = [Worker(ident) for ident in range(thread_count)]

    def execute(self,
                mode: str = "asynch") -> None:
        """
        Executes all tasks within the given task pool, using the defined number of
        worker threads. The tasks are either processed asynchronously or synchronously.
        However, the ordering of results does not change.

        :param mode: Execution mode. Available modi are "asynch" and "joined" dor either asynchronous
            or synchronous task execution. Asynchronous mode is faster, but produces more overhead.
        """

        if mode == "asynch":

            while self.task_pool.has_next():

                # Delegate available tasks to idle workers
                for worker in [idl_worker for idl_worker in self.workers if not idl_worker.is_busy()]:
                    worker.run_task(self.task_pool.next())

                time.sleep(0.5)  # Only check workers every .5 second to save resources

            # Join remaining workers
            for worker in [worker for worker in self.workers]:
                worker.join_task()

        elif mode == "joined":

            while self.task_pool.has_next():

                # Delegate available tasks to all workers
                for worker in [idl_worker for idl_worker in self.workers if not idl_worker.is_busy()]:
                    worker.run_task(self.task_pool.next())

                # Join all workers
                for worker in [worker for worker in self.workers]:
                    worker.join_task()

    def extract_returns(self) -> List[any]:
        """
        Returns the ordered results of the processed tasks. This method only
        delivers values, if the execute method has been invoked beforehand. The
        ordering of results is the same as the ordering within the task pool.
        """
        return [task.returnable for task in self.task_pool]
