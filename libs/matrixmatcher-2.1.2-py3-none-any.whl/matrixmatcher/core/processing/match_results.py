"""
Wraps class: MatchResults
"""

from typing import List
import pandas as pd
import numpy as np
import copy
import pickle

from ..indexing.neighborhood import Neighborhood
from ...utils.system import deprecation_warning_alias
from ..matrix.match_matrix import MatchMatrix
from ..exceptions import InvalidMatchCaseException, DtArgumentException, InvalidCombinationException, \
    InvalidCommandException, ResultsComputationException, DeserializationException
from .id_generation import calculate_tuple_id, calculate_match_id
from ..processing.time_measurement import TimeMeasurementCollection


class MatchResults:
    """
    Stores all relevant results of the main process and allows
    all corresponding evaluations.
    """

    def __init__(self,
                 matchedTuples: pd.DataFrame,
                 df1: pd.DataFrame,
                 df2: pd.DataFrame,
                 matrix: MatchMatrix,
                 neighborhoods: List[Neighborhood],
                 isIntra: bool,
                 time_measurements: TimeMeasurementCollection = None,
                 tuple_count: int = -1):
        """
        Constructs MatchResults object.

        :param matchedTuples: DataFrame containing indices and
            grouping of matched record tuples with structure:
            [case_0, ..., case_n, df1, df2, tuple_ID, match_ID, ... surplus]
        :param df1: Input DataFrame 1,  of which indices are referenced in
            matchedTuples as column "df1".
        :param df2: Input DataFrame 2,  of which indices are referenced in
            matchedTuples as column "df2".
        :param matrix: MatchMatrix object that was utilized in obtaining the
            matchedTuples DataFrame through the main process.
        :param neighborhoods: Neighborhood objects that were utilized in obtaining the
            matchedTuples DataFrame through the main process.
        """

        self.df1 = df1
        self.df2 = df2
        self.isIntra = isIntra
        self.neighborhoods = neighborhoods
        self.matrix = matrix
        self.matchedTuples = matchedTuples
        self.time_measurements = time_measurements
        self.tuple_count = tuple_count
        self.duplicates_flat = None
        self.duplicates = None

    @property
    def matchedTuples(self):
        return self._matchedTuples

    @property
    def duplicates(self):
        if self._duplicates is None:
            self.calculate_duplicates()
        return self._duplicates

    @property
    def duplicates_flat(self):
        if self._duplicates_flat is None:
            self.calculate_duplicates()
        return self._duplicates_flat

    @duplicates.setter
    def duplicates(self, duplicates):
        self._duplicates = duplicates

    @duplicates_flat.setter
    def duplicates_flat(self, duplicates_flat):
        self._duplicates_flat = duplicates_flat

    @matchedTuples.setter
    def matchedTuples(self, matchedTuples):
        self._matchedTuples = matchedTuples

        # Set tuple_ID
        self._matchedTuples['tuple_ID'] = calculate_tuple_id(
            self._matchedTuples['df1'],
            self._matchedTuples['df2']
        )

        # Set match_ID
        self.matchedTuples["match_ID"] = calculate_match_id(
            self.matchedTuples["df1"],
            self.matchedTuples["df2"],
            self.isIntra
        )

    # LOGIC
    ##################

    def calculate_duplicates(self,
                             hidden_cases: set = None,
                             hidden_ids: set = None,
                             hide_metrics: bool = False,
                             hide_surplus_fields: bool = False) -> None:
        """
        Builds the complete result table from internal attributes.
        The resulting table has the following structure:
        [case_0, ..., case_n, field_1_metric, ..., field_n_metric, tuple_ID, match_ID,
        index_df1, index_df2, ... surplus fields]

        :param hidden_cases: Cases that shall not be considered in the calculations.
            This is different from a simple pandas query or loc and triggers a complete
            re-calculation of the match_ID, because MatchCases can influence one another.
            Always use this parameter to hide cases.
        :param hidden_ids: Ids that shall not be considered in the calculation.
            Choose either 'tuple' OR 'match'. If tuple_ID is hidden, the number of rows
            in the resulting DataFrame will decrease dramatically.
        :param hide_surplus_fields: Shall all irrelevant data fields be hidden? This impacts
            all fields, that are not used in the MatchMatrix object as MatrixFields.
        :param hide_metrics: Shall all string metric columns be hidden?
        """

        if hidden_ids is None:
            hidden_ids = set()
        if hidden_cases is None:
            hidden_cases = set()

        # Preparing data
        #################################

        # Hide string metrics
        if hide_metrics:
            self.matchedTuples.drop(
                columns=self.matrix.get_feature_columns(), inplace=True
            )

        # Hide cases
        if hidden_cases:
            try:
                hidden_cases = {'case_' + str(case) for case in hidden_cases}

                self.matchedTuples = self.matchedTuples.loc[
                    self.matchedTuples[list(hidden_cases)].sum(axis=1) == 0
                    ]

                # Reset match_ID
                self.matchedTuples["match_ID"] = calculate_match_id(
                    self.matchedTuples["df1"],
                    self.matchedTuples["df2"],
                    self.isIntra
                )

            except KeyError:
                raise InvalidMatchCaseException()

        # Hide tuple_ID
        if 'tuple' in hidden_ids:
            self.matchedTuples.drop(
                columns={'tuple_ID'}, inplace=True
            )

        # Calculate (or hide) id for each duplicate group and insert as column
        if 'match' in hidden_ids:
            try:
                self.matchedTuples.drop(
                    columns={'match_ID'}, inplace=True
                )
            except KeyError:
                ...

        self.df1['index_df1'] = self.df1.index
        self.df2['index_df2'] = self.df2.index

        self.matchedTuples.reset_index(drop=True, inplace=True)

        # Copy rows. For each matched record one row
        #################################

        matchesDf1 = self.matchedTuples.copy(deep=True)
        matchesDf1['df2'] = -1

        matchesDf2 = self.matchedTuples.copy(deep=True)
        matchesDf2['df1'] = -1

        matches_long = pd.concat(
            [matchesDf1, matchesDf2],
            axis=0
        )

        self.df1['df1'] = self.df1.index
        self.df1['df1'] = self.df1['df1'].astype(int)

        self.df2['df2'] = self.df2.index
        self.df2['df2'] = self.df2['df2'].astype(int)

        # Building final result table
        #################################

        # Step1: Merge df1
        duplicates = matches_long.merge(
            self.df1,
            how='left',
            on='df1'
        )

        # Rename potentially old match_ID column
        if 'match_ID' in self.df1.columns:
            duplicates.rename(
                columns={
                    'match_ID_y': 'match_ID_OLD_df1',
                    'match_ID_x': 'match_ID'
                }, inplace=True
            )

        # Sort values in output frame
        order_by = ['match_ID', 'tuple_ID']

        if 'match' in hidden_ids:
            order_by = ['tuple_ID']
        if 'tuple' in hidden_ids:
            order_by = ['match_ID']

        if not self.isIntra:

            # Step2: Merge df2
            duplicates = duplicates.merge(
                self.df2,
                how='left',
                on='df2',
                suffixes=('_df1', '_df2')
            )

            # Rename potentially old match_ID column
            if 'match_ID' in self.df2.columns:
                duplicates.rename(
                    columns={
                        'match_ID_df2': 'match_ID_OLD_df2',
                        'match_ID_df1': 'match_ID'
                    }, inplace=True
                )

            # Arrange columns in result table
            duplicates = duplicates.sort_values(
                by=order_by
            ).drop(columns={'df1', 'df2'})

            # Drop temporary columns in input frame
            self.df1.drop(columns={'df1', 'index_df1'}, inplace=True)
            self.df2.drop(columns={'df2', 'index_df2'}, inplace=True)

        else:  # For intra matching

            # Step2: Merge df2
            duplicates = duplicates.merge(
                self.df2,
                how='left',
                left_on='df2_x',
                right_on='df2',
                suffixes=('_df1', '_df2')
            )

            # Rename potentially old match_ID column
            if 'match_ID' in self.df2.columns:
                duplicates.rename(
                    columns={
                        'match_ID_df2': 'match_ID_OLD_df2',
                        'match_ID_df1': 'match_ID'
                    }, inplace=True
                )

            # Arrange columns in result table
            duplicates = duplicates.sort_values(
                by=order_by
            ).drop(
                columns={
                    'df1_df1',
                    'df1_df2',
                    'df2_x',
                    'df2_y',
                    'df2',
                    'index_df1_df2',
                    'index_df2_df1'
                }
            ).rename(
                columns={
                    'index_df1_df1': 'index_df1',
                    'index_df2_df2': 'index_df2',
                }
            )

            # Drop temporary columns in input frame
            self.df1.drop(
                columns={'df1', 'df2', 'index_df1', 'index_df2'},
                inplace=True
            )

        # Hide surplus input fields
        if hide_surplus_fields:
            duplicates = duplicates[
                [col for col in duplicates.columns if "case_" in col] +
                (self.matrix.get_feature_columns() if not hide_metrics else []) +
                (['match_ID'] if 'match' not in hidden_ids else []) +
                (['tuple_ID'] if 'tuple' not in hidden_ids else []) +
                [col + '_df1' for col in self.matrix.get_field_names()] +
                ['index_df1'] +
                [col + '_df2' for col in self.matrix.get_field_names()] +
                ['index_df2']
            ]

        self._duplicates = duplicates.drop_duplicates()

        # Calculate flat instance
        duplicates_flat = self._duplicates.copy(deep=True)
        to_flatten = ([_ for _ in duplicates_flat.columns if 'index' not in _]
                      if not self.isIntra else
                      duplicates_flat.columns)

        for col in to_flatten:
            if '_df1' in col:
                col = col.replace('_df1', '')
                duplicates_flat.loc[
                    duplicates_flat[col + '_df1'].isnull(), col + '_df1'
                ] = duplicates_flat[col + '_df2']

                duplicates_flat = duplicates_flat.drop(
                    columns={col + '_df2'}).rename(columns={col + '_df1': col})

        self._duplicates_flat = duplicates_flat

    # USER METHODS
    ##################

    def hide(self,
             cases: set = None,
             ids: set = None,
             metrics: bool = False,
             surplus_fields: bool = False):
        """
        Hides certain sets of columns and returns an appropriate copy of
        the results object. The nature of this method may lead to delayed
        responses or excessive use of memory when applied to very big input
        DataFrames (attributes df1 and df2).

        :param cases: Cases that shall not be considered in the calculations.
            This is different from a simple pandas query or loc and triggers a complete
            re-calculation of the match_ID, because MatchCases can influence one another.
            Always use this parameter to hide cases.
        :param ids: Ids that shall not be considered in the calculation.
            Choose either 'tuple' OR 'match'. If tuple_ID is hidden, the number of rows
            in the resulting DataFrame will decrease dramatically.
        :param surplus_fields: Shall all irrelevant data fields be hidden? This impacts
            all fields, that are not used in the MatchMatrix object as MatrixFields.
        :param metrics: Shall all string metric columns be hidden?
        :return: Copy of the MatchResults object with applied filters.
        """

        if cases is None:
            cases = set()
        if ids is None:
            ids = set()

        # Validate input
        if not isinstance(cases, set):
            raise DtArgumentException('cases', 'set')
        if not isinstance(ids, set):
            raise DtArgumentException('ids', 'set')
        if not isinstance(metrics, bool):
            raise DtArgumentException('metrics', 'bool')
        if not isinstance(surplus_fields, bool):
            raise DtArgumentException('surplus_fields', 'bool')

        if 'match' in ids and 'tuple' in ids:
            raise InvalidCombinationException('match', 'tuple')
        elif len(ids) > 0 and not ('match' in ids or 'tuple' in ids):
            raise InvalidCommandException('ids', ['match', 'tuple'])

        # Copy instance!
        self_cpy = copy.deepcopy(self)

        try:
            self_cpy.calculate_duplicates(
                hidden_cases=cases,
                hidden_ids=ids,
                hide_metrics=metrics,
                hide_surplus_fields=surplus_fields
            )
        except Exception:
            raise ResultsComputationException()

        return self_cpy

    def check_false_negatives(self, nhood: int = 0) -> pd.DataFrame:
        """
        Provides an output table to visually identify false negatives
        in matching results.

        :param nhood: Index of the Neighborhood object within the attribute
            "neighborhoods" to sort the output table by. Different sorting
            fields i.e. neighborhoods can lead to different results.
        :return: The source DataFrames (attributes df1 and df2) are merged and
            sorted via the chosen sorted neighborhood. The return contains the
            identified duplicate groups (columns match_ID). If neighboring record
            pairs are duplicates and do not exhibit a grouping, a false negative can
            be assumed.
        """

        if nhood >= len(self.neighborhoods):
            raise DtArgumentException(
                'nhood', 'int from 0 to ' + str(len(self.neighborhoods) - 1)
            )

        if not self.isIntra:

            self.df1['df1'] = self.df1.index
            self.df2['df2'] = self.df2.index

            # Fusion and sorting of input data, based on neighborhood fields

            fusion = pd.concat(
                [self.df1,
                 self.df2],
                axis=0
            ).sort_values(by=self.neighborhoods[nhood].fieldNames)

            self.df1.drop(columns={'df1'}, inplace=True)
            self.df2.drop(columns={'df2'}, inplace=True)

            fusion = fusion.merge(
                self.matchedTuples[
                    ['match_ID', 'df1']
                ].drop_duplicates('df1').dropna(),
                on='df1',
                how='left'
            ).merge(
                self.matchedTuples[
                    ['match_ID', 'df2']
                ].drop_duplicates('df2').dropna(),
                on='df2',
                how='left'
            )

            fusion["match_ID_x"] = np.where(
                fusion['match_ID_x'].isnull(),
                fusion['match_ID_y'],
                fusion["match_ID_x"]
            )

            fusion = fusion.drop(
                columns={'match_ID_y'}
            ).rename(columns={'match_ID_x': 'match_ID'})

        else:

            self.df1['index'] = self.df1.index
            fields = self.neighborhoods[nhood].fieldNames + ['index']

            # Sorting of input data, based on neighborhood fields

            fusion = self.df1[fields].sort_values(
                by=self.neighborhoods[nhood].fieldNames
            )

            self.df1.drop(columns={'index'}, inplace=True)

            fusion = fusion.merge(
                self.matchedTuples[
                    ['match_ID', 'df1']
                ].drop_duplicates('df1').dropna(),
                left_on='index',
                right_on='df1',
                how='left'
            ).merge(
                self.matchedTuples[
                    ['match_ID', 'df2']
                ].drop_duplicates('df2').dropna(),
                left_on='index',
                right_on='df2',
                how='left'
            )

            fusion["match_ID_x"] = np.where(
                fusion['match_ID_x'].isnull(),
                fusion['match_ID_y'],
                fusion["match_ID_x"]
            )

            fusion = fusion.drop(
                columns={'match_ID_y', 'df2', 'df1'}
            ).rename(columns={'match_ID_x': 'match_ID'})

        return fusion

    def check_false_positives(self, fields: set) -> pd.DataFrame:
        """
        Provides an output table to visually identify false positives.
        Returns sorted (based on similarity values) records with the weakest
        identified matches at the top of the table.

        :param fields: MatrixField label to find false positives for.
            E.g. field = "Company_name" (if present in MatchMatrix)
            shows the weakest matches for company names.
        :result: Sorted DataFrame with the weakest at the top
            (ascending similarity values)
        """

        if (len(fields) == 0 or
                len(set.intersection(
                    set(self.matrix.get_field_names()), fields
                )) != len(fields)):
            raise InvalidCommandException(
                'fields', self.matrix.get_field_names()
            )

        order_by = [
            field.get_feature_column() for field in self.matrix.fields
            if field.fieldname in fields
        ]

        try:
            return self.duplicates.sort_values(
                (order_by + ['match_ID']), ascending=True
            )
        except KeyError:
            raise InvalidCombinationException(
                'hide(metrics=True)', 'check_false_positives'
            )

    def get_input_with_ids(self, ids: set = None) -> pd.DataFrame:
        """
        Returns the input DataFrame(s) (attributes df1 and df2) with
        the chosen ids as new columns. This can be used either to merge
        based on these columns or to flag duplicates in the source tables.

        :param ids: Set of chosen ids ('match' and/or 'tuple') to insert
            into source DataFrames.
        :return: Input DataFrame(s) (attributes df1 and df2) with
        the chosen ids as new columns.
        """

        if ids is None:
            ids = {'match'}

        hiddenIds = set()
        if 'match' not in ids:
            hiddenIds = {'match_ID'}
        elif 'tuple' not in ids:
            hiddenIds = {'tuple_ID'}

        if len(ids) == 0:
            raise InvalidCommandException(
                'ids', ['match', 'tuple']
            )

        idCols = [id_ + '_ID' for id_ in ids]

        if not self.isIntra:

            self.df1['df1'] = self.df1.index
            self.df2['df2'] = self.df2.index

            out = [
                self.df1.merge(
                    self.matchedTuples.drop(columns=hiddenIds)[
                        idCols + ['df1']
                    ].dropna().drop_duplicates(),
                    on='df1',
                    how='left'
                ).drop(columns={'df1'}),
                self.df2.merge(
                    self.matchedTuples.drop(columns=hiddenIds)[
                        idCols + ['df2']
                    ].dropna().drop_duplicates(),
                    on='df2',
                    how='left'
                ).drop(columns={'df2'})
            ]

            self.df1.drop(columns={'df1'}, inplace=True)
            self.df2.drop(columns={'df2'}, inplace=True)

        else:

            self.df1['index'] = self.df1.index

            out = self.df1.merge(
                self.matchedTuples.drop(columns=hiddenIds)[
                    idCols + ['df1']
                    ].dropna().drop_duplicates(),
                left_on='index',
                right_on='df1',
                how='left'
            ).merge(
                self.matchedTuples.drop(columns=hiddenIds)[
                    idCols + ['df2']
                    ].dropna().drop_duplicates(),
                left_on='index',
                right_on='df2',
                how='left'
            ).drop(columns={'index'})

            for col in idCols:
                out[col] = np.where(
                    out[col + '_x'].isnull(),
                    out[col + '_y'],
                    out[col + '_x']
                )
                out.drop(columns={col + '_y', col + '_x'}, inplace=True)

            out.drop(columns={'df1', 'df2'}, inplace=True)
            self.df1.drop(columns={'index'}, inplace=True)
            out = out.drop_duplicates()

        return out

    def get_mapping(self,
                    base: str = 'match',
                    exclude: set = None,
                    drop_id: bool = True) -> pd.DataFrame:
        """
        Returns the mapping of duplicated records base on duplicate tuples
        or duplicate groups within the input DataFrames (attributes df1 and df2).
        Connects the input DataFrames via unique row indices.

        E.g.:
        df1  |  df2 | (match_ID) OR (tuple_ID)
        1       254   1             1_254
        34      566   1             34_566
        ...
        45      81    2             45_81
        ...

        :param base: Use either "tuple" OR "match" as the base for this mapping.
            "tuple" maps only connected tuples (1:1). "match" links every record within
            the same match_ID grouping to one another (n:n).
        :param exclude: Exclude specific match_IDs or tuple_IDs from the mapping.
            match_IDs can be passed as integers; tuple_IDs must be passed as strings.
        :param drop_id: Shall the id (match_ID or tuple_ID) column be dropped from the output?
        :return: Mapping of unique row indices.
        """

        if exclude is None:
            exclude = set()

        if base != 'match' and base != 'tuple':
            raise InvalidCommandException(
                'base', ['match', 'tuple']
            )

        mapping = pd.DataFrame()
        exclude = {str(i) for i in exclude}

        if base == 'tuple':

            mapping = self.matchedTuples.loc[
                ~self.matchedTuples['tuple_ID'].isin(exclude)
            ][
                ["df1", "df2"] if drop_id else ["df1", "df2", "tuple_ID"]
            ].drop_duplicates()

        elif base == 'match':

            mapping = self.matchedTuples.loc[
                ~self.matchedTuples['match_ID'].isin(exclude)
            ][
                ["df1", "df2"] if drop_id else ["df1", "df2", "match_ID"]
            ].drop_duplicates()

        return mapping

    def compare_duplicates(self, other) -> List[pd.DataFrame]:
        """
        Compares two matching results (based on the same input data)
        and identifies differences in match_ID groupings.

        ! Intra-matching is not supported yet !

        Keyword Arguments:
        :param other: MatchResults of the second matching process. The input
            DataFrames of this process must be the same that have been used
            in the first matching process.
        :returns: A list containing two DataFrames with a reference for df1 at
            index 0 and a reference for df2 at index 1. The columns match_ID_1
            and match_ID_2 represent a mapping of the corresponding
            two match_ID groupings originating from the first and the second
            matching.
        """

        if self.isIntra or other.isIntra:
            raise NotImplementedError(
                "The comparison of intra-matching is not supported yet."
            )

        self.df1['df1'] = self.df1.index
        self.df2['df2'] = self.df2.index

        df1_mid = self.df1[["df1"]].merge(
            self.matchedTuples[['match_ID', 'df1']].dropna().drop_duplicates(),
            on='df1',
            how='left'
        ).merge(
            other.matchedTuples[['match_ID', 'df1']].dropna().drop_duplicates(),
            on='df1',
            how='left',
            suffixes=('_1', '_2')
        )

        df2_mid = self.df2[["df2"]].merge(
            self.matchedTuples[['match_ID', 'df2']].dropna().drop_duplicates(),
            on='df2',
            how='left'
        ).merge(
            other.matchedTuples[['match_ID', 'df2']].dropna().drop_duplicates(),
            on='df2',
            how='left',
            suffixes=('_1', '_2')
        )

        self.df1.drop(columns={'df1'}, inplace=True)
        self.df2.drop(columns={'df2'}, inplace=True)

        return [df1_mid, df2_mid]

    def to_pickle(self, path: str):
        """
        Serializes the MatchResults instance to a pickle file.

        :param path: Path to the output file.
        """
        pickle.dump(self, open(path, 'wb'))

    @staticmethod
    def from_pickle(path: str):
        """
        Generates an instance of MatchResults from a compatible
        pickle file.

        :param path: Path to the input file.
        :return: Deserialized MatchResults object.
        """
        try:
            return pickle.load(open(path, 'rb'))
        except AttributeError:
            raise DeserializationException("MatchResults")

    #############
    # DEPRECATION
    #############

    @deprecation_warning_alias("check_false_negatives")
    def checkForFalseNegatives(self, *args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'check_false_negatives'.
        """
        return self.check_false_negatives(*args, **kwargs)

    @deprecation_warning_alias("check_false_positives")
    def checkForFalsePositives(self, *args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'check_false_positives'.
        """
        return self.check_false_positives(*args, **kwargs)

    @deprecation_warning_alias("get_input_with_ids")
    def getInputWithIDs(self, *args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'get_input_with_ids'.
        """
        return self.get_input_with_ids(*args, **kwargs)

    @deprecation_warning_alias("get_mapping")
    def getMapping(self, *args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'get_mapping'.
        """
        return self.get_mapping(*args, **kwargs)

    @deprecation_warning_alias("compare_duplicates")
    def compareDuplicates(self, *args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'compare_duplicates'.
        """
        return self.compare_duplicates(*args, **kwargs)

    @deprecation_warning_alias("to_pickle")
    def toPickle(self, *args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'to_pickle'.
        """
        return self.to_pickle(*args, **kwargs)

    @deprecation_warning_alias("from_pickle")
    def fromPickle(*args, **kwargs):
        """
        Deprecated function name.
        Please refer to name 'from_pickle'.
        """
        return MatchResults.from_pickle(*args, **kwargs)
