"""
Wraps class: TimeMeasurement
"""

import time
from typing import Set

from ..exceptions import DtArgumentException


class TimeMeasurement:
    """
    Simple time measurement with duration and label.
    """

    def __init__(self, start: float, label: str):
        self.start = start
        self.end = time.perf_counter()
        self.label = label

    @property
    def duration(self):
        """Duration in milliseconds."""
        return (self.end - self.start) * 1000


class TimeMeasurementCollection(list):
    """
    Collects object of type TimeMeasurement and supplies specialized methods
    for those objects.
    """

    def __init__(self, *args):
        if all(isinstance(arg, TimeMeasurement) for arg in args):
            super().__init__(args)
        else:
            raise DtArgumentException("arg", "TimeMeasurement")

    @property
    def sum(self) -> float:
        """Sum of durations of all contained TimeMeasurements"""
        return sum([measurement.duration for measurement in self])

    @property
    def average(self) -> float:
        """Average of durations of all contained TimeMeasurements"""
        return sum([measurement.duration for measurement in self])/len(self)

    def where(self, label: str):
        """
        Returns a subset of the given TimeMeasurementCollection
        instance with matching labels.

        :param label: Label of the desired TimeMeasurement instances.
        :returns: TimeMeasurementCollection
        """

        return TimeMeasurementCollection(
            *[measurement for measurement in self if measurement.label == label]
        )

    def concat(self, measurement: [TimeMeasurement, list]):
        """
        Concatenates two TimeMeasurementCollection (or one TimeMeasurementCollection
        and one TimeMeasurement object) into a single TimeMeasurementCollection.

        :param measurement: TimeMeasurementCollection or TimeMeasurement to concatenate
            to given TimeMeasurementCollection.
        :returns: combined TimeMeasurementCollection
        """

        if isinstance(measurement, TimeMeasurement):
            return TimeMeasurementCollection(self, measurement)
        elif isinstance(measurement, list):
            return TimeMeasurementCollection(self, *measurement)

    def get_labels(self) -> Set[str]:
        """Returns all unique labels"""
        return {measurement.label for measurement in self}

    def append_values(self,  label: str, start: float) -> None:
        """Constructs and appends a TimeMeasurement object to the collection."""
        measurement = TimeMeasurement(start, label)
        if isinstance(measurement, TimeMeasurement):
            self.append(measurement)


# Globally accessible collection.
measurements = TimeMeasurementCollection()
