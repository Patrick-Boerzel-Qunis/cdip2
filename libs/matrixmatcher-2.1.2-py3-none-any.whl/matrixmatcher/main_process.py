"""
Main Process and core functionalities of MatrixMatcher.
"""
import itertools as it
import os
import sys
import time
from dataclasses import dataclass
from multiprocessing import Process, Queue
from typing import List
import pandas as pd
import warnings
import numpy as np

from .core.matrix.match_matrix import MatchMatrix
from .core.indexing.indexer import Indexer
from .core.processing.match_results import MatchResults
from .utils.system import message_out, set_setting
from .core.processing.id_generation import calculate_tuple_id
from .core.processing.job_orchestration import TaskPool, Task, TaskOrchestrator
from .core.processing.time_measurement import measurements, TimeMeasurementCollection

from .core.exceptions import ArgumentNotDefinedException, \
    DtArgumentException, MemoryReferenceException, \
    AmbiguousIndexException, InputFieldNameException, \
    DtFieldException, InvalidArgumentException, TooManyProcessesException

_is_intra = False  # Defines an intra duplicate search
_disable_msgs = False  # Disables all console outputs of the main process

warnings.filterwarnings('ignore')


@dataclass
class ProcessReturnable:
    """
    Class to transfer results between processes through Queue objects.
    """
    matchedTuples: List[pd.DataFrame]
    tuple_count: int
    time_measurements: TimeMeasurementCollection
    exception: BaseException = None


def match(**kwargs) -> [MatchResults, None]:
    """
    Main matching process. This function coordinates subprocesses and
    returns corresponding matching results as a MatchResults object.

    Define the argument 'df1' and not 'df2' to perform intra duplicate
    search of 'df1' and identify only duplicates within df1. If you pass both,
    the classic matching process between the two DataFrames is conducted and duplicate
    groups are created with records from both DataFrames.

    !! THIS FUNCTION TAKES NO POSITIONAL ARGUMENTS !!

    :param kwargs:
        df1 (pandas.DataFrame OR List[pandas.DataFrame]) -- input dataFrame 1. All columns, specified in
            the neighborhood(s) and matrix must be present in this DataFrame as well. If a list object is
            passed, all elements within the list are concatenated into a single DataFrame.
        df2 (pandas.DataFrame  OR List[pandas.DataFrame]) -- (optional) input dataFrame 2. All columns, specified in
            the neighborhood(s) and matrix must be present in this DataFrame as well. If a list object is
            passed, all elements within the list are concatenated into a single DataFrame.
        matrix (MatchMatrix) -- MatchMatrix object that hosts all relevant matching preferences
            and provides a decision model for the interpretation of duplicates.
        neighborhoods (List[Neighborhood]) -- Sorted neighborhoods with specified sorting
            columns to sort the merged table by. Also containing the size of
            the sliding window, which is the basis for the tuple selection (indexing).
        disable_msgs (bool) -- Shall all console outputs of this process be muted?
        threading_settings (dict) -- Enables the use of multiple threads in the main process.
            Usage: {'threads': x, 'slicesize': y}: Performs the main process
            with x threads and processes the smaller of the two input DataFrames
            (or the first one, if size does not differ) in chunks of y records per thread.
        queue (Queue) -- Only set, if the process is started through function match_multiprocessing.
            This queue ensures a process safe communication of ProcessReturnable objects between the
            individual processes.
        force_intra (bool) -- True, if the main process passes two DataFrames, that originate from the
            same DataFrame. This implies a forced intra matching regardless of other evaluation steps.
    :return: MatchResults object containing all relevant matching information. Returns None, if
        multiprocessing is enabled and the results are written into a Queue object.
    """

    global _is_intra
    global _disable_msgs

    # Argument evaluation (mandatory args)
    ################################

    valid_argument_names = [
        "disable_msgs",
        "df1",
        "df2",
        "matrix",
        "neighborhoods",
        "threading_settings",
        "queue",
        "force_intra"
    ]

    if not all([kw in valid_argument_names for kw in kwargs.keys()]):
        err_arg = [kw for kw in kwargs.keys() if kw not in valid_argument_names][0]
        raise InvalidArgumentException(err_arg, "match")

    _disable_msgs = kwargs.get('disable_msgs', False)

    try:
        df1 = kwargs['df1']
        if isinstance(df1, list):
            df1 = pd.concat(df1, axis=0)
        elif not isinstance(df1, pd.DataFrame):
            raise TypeError()
    except (KeyError, AttributeError, TypeError) as ex:
        if isinstance(ex, KeyError):
            raise ArgumentNotDefinedException('df1')
        else:
            raise DtArgumentException('df1', 'pandas.DataFrame OR List[pandas.DataFrame]')

    try:
        matrix = kwargs['matrix']
        if not isinstance(matrix, MatchMatrix):
            raise DtArgumentException('matrix', 'MatchMatrix')
    except KeyError:
        raise ArgumentNotDefinedException('matrix')

    try:
        neighborhoods = kwargs['neighborhoods']
        if not isinstance(neighborhoods, list):
            raise DtArgumentException('neighborhoods', 'list[Neighborhood]')
    except KeyError:
        raise ArgumentNotDefinedException('neighborhoods')

    # Argument evaluation (optional args)
    ################################

    try:  # Classical two frame matching
        df2 = kwargs['df2']
        if isinstance(df2, list):
            df2 = pd.concat(df2, axis=0)
        elif not isinstance(df2, pd.DataFrame):
            raise TypeError()
        _is_intra = False
    except (KeyError, AttributeError, TypeError) as ex:
        if isinstance(ex, KeyError):
            df2 = df1  # Intra matching
            _is_intra = True
        else:
            raise DtArgumentException('df1', 'pandas.DataFrame OR List[pandas.DataFrame]')

    try:  # Check if intra matching is enforced by the main process
        force_intra = kwargs['force_intra']
        if not isinstance(force_intra, bool):
            raise DtArgumentException('force_intra', 'bool')
        if force_intra:
            _is_intra = True
    except KeyError:
        ...

    try:  # Set multithreading preferences
        threading_settings = kwargs['threading_settings']
        if not isinstance(threading_settings, dict):
            raise DtArgumentException('threading_settings', 'dict')
    except KeyError:  # Use single thread

        # The extraction of MatchMatrix's attribute is only
        # for legacy compatibility! Remove once matrix.set_setting() is removed.
        threading_settings = matrix.settings["parallel_processing"]

        # Future replacement (along with deletion of
        # set_setting() method on MatchMatrix):
        # threading_settings = {'threads': 1, 'slicesize': -1}

    try:  # Set multiprocessing preferences
        queue = kwargs['queue']
        if not isinstance(queue, type(Queue())):
            raise DtArgumentException('queue', 'Queue')
    except KeyError:
        queue = None

    # Validating configurations
    ################################

    if not _is_intra and (id(df1) == id(df2)):
        raise MemoryReferenceException('df1', 'df2')
    elif not df1.index.is_unique:
        raise AmbiguousIndexException('df1')
    elif not df2.index.is_unique:
        raise AmbiguousIndexException('df2')

    # Validate field names of input DataFrames
    for i in range(len(matrix.fields)):
        if not ((matrix.fields[i].fieldname in df1.columns) &
                (matrix.fields[i].fieldname in df2.columns)):
            raise InputFieldNameException(
                'MatchMatrix', matrix.fields[i].fieldname, 'df1/df2'
            )

    # Validate data types of the input columns
    for col in matrix.get_field_names():
        if df1[col].dtype != df2[col].dtype:
            raise DtFieldException(col, str(df1[col].dtype), str(df2[col].dtype))

    # Validate field names in neighborhoods
    for nh in neighborhoods:
        for field in nh.fieldNames:
            if field not in matrix.get_field_names():
                raise InputFieldNameException(
                    'Neighborhood', field, 'MatchMatrix'
                )

    # Apply global settings
    ################################

    # Disable message_out globally  (optional)
    set_setting('disable_msgs', _disable_msgs)

    message_out(msg=f"<STARTING> up process with ident {str(os.getpid())}",
                filler=(os.getpid() if queue is not None else ' '))

    # Run subprocesses
    ################################

    start_time = time.perf_counter()

    slice_df1 = df1.shape[0] <= df2.shape[0]

    slices = slice_dataframe(
        df=(df1 if slice_df1 else df2),
        slice_size=threading_settings["slicesize"]
    )  # Slice df1 or df2 depending on record count

    tpool = TaskPool()
    for slc in slices:

        indexer = Indexer(
            neighborhoods,
            (slc if df1.shape[0] <= df2.shape[0] else df1),
            (df2 if df1.shape[0] <= df2.shape[0] else slc)
        )
        tpool.append(
            Task(
                func=matching_process,
                arguments=[matrix, indexer]
            )
        )

    orchestrator = TaskOrchestrator(
        task_pool=tpool,
        thread_count=threading_settings["threads"]
    )

    message_out(msg=f"<MATCHING> records for process {str(os.getpid())}",
                filler=(os.getpid() if queue is not None else ' '))
    orchestrator.execute("asynch")

    matches = pd.DataFrame()
    for task_res in orchestrator.extract_returns():
        matches = pd.concat(
            [matches, task_res],
            axis=0
        )

    # Finalize results
    ################################

    message_out(msg=f"<FINALIZING> results for process with ident {str(os.getpid())}",
                filler=(os.getpid() if queue is not None else ' '))

    # Special values for logging purposes
    measurements.append_values(
        start=start_time,
        label="main_process"
    )

    # noinspection PyBroadException
    try:
        # noinspection PyProtectedMember
        tuple_count = sum([task._args[1].tuples.shape[0] for task in tpool])
    except Exception:
        tuple_count = -2

    if queue is None:  # Choose this route, if multiprocessing is DISABLED.

        # Build final results object
        results = MatchResults(
            matchedTuples=matches,
            df1=df1,
            df2=df2,
            matrix=matrix,
            neighborhoods=neighborhoods,
            isIntra=_is_intra,
            time_measurements=measurements,
            tuple_count=tuple_count
        )

        message_out('! Matching completed !')

        if not _is_intra:
            message_out(
                '<Info> Identified '
                + str(results.matchedTuples.shape[0] * 2)
                + ' unique potential duplicate(s) in DF1 and DF2.'
            )
        else:
            message_out(
                '<Info> Identified '
                + str(results.matchedTuples.shape[0] * 2)
                + ' unique potential duplicate(s) in DF1.'
            )

        return results

    else:  # Choose this route, if multiprocessing is ENABLED.
        queue.put(
            ProcessReturnable(
                matchedTuples=slice_by_size(matches),
                tuple_count=tuple_count,
                time_measurements=measurements
            )
        )


########################################################
# SUBPROCESSES
########################################################


def matching_process(worker_ident: int,
                     matrix: MatchMatrix,
                     indexer: Indexer) -> pd.DataFrame:
    """
    Subprocess. Executes the actual matching processes and
    is called by the main process (match).

    :param matrix: MatchMatrix object. Contains the decision model
        to classify record tuples.
    :param worker_ident: Identification number of the current thread.
        Used for logging purposes.
    :param indexer: Indexer object. The indexer has to be initialized
        with the input DataFrames.
    """

    global _is_intra

    # Indexing of the current Slice and input frame
    if not _is_intra:
        indexer.index(worker_ident)
    else:
        indexer.index_intra(worker_ident)

    # Calculating feature table
    ################################

    processed_condition_ids = []

    features = indexer.tuples

    features["tuple_ID"] = calculate_tuple_id(
        features["df1"], features["df2"]
    )

    features.insert(0, "keep", 1)

    performance_prioritized_indices = [
        matrix.fields.index(mf) for mf in sorted(matrix.fields)
    ]

    for mx_i in performance_prioritized_indices:

        # tuple_IDs to exclude from the next feature calculation
        exclude = features.query('keep==0')["tuple_ID"]

        # Calculation of similarities for the current MatrixField (feature)

        start_time = time.perf_counter()

        curr_feature = indexer.compare_field_by_field(
            matrix_field=matrix.fields[mx_i],
            thnum=worker_ident,
            exclude=(exclude if exclude.shape[0] > 0 else None)
        )

        measurements.append_values(
            start=start_time,
            label="string_similarity_column"
        )

        # Application of conditions and options per feature column
        # If a tuple record does not fulfill ANY condition on one
        # feature field, it is excluded from later calculation steps.
        start_time = time.perf_counter()
        for case in matrix.cases:

            # Index of MatrixField equals index of
            # condition for each case!
            condition = case.conditions[mx_i]
            processed_condition_ids.append(condition.id)
            curr_feature_col = matrix.fields[mx_i].get_feature_column()

            curr_feature.insert(len(curr_feature.columns), condition.id, 0)

            if condition.option == '+':  # Rule: Both fields must be filled

                curr_feature[condition.id] = np.where(
                    curr_feature[curr_feature_col] >= condition.value,
                    1, 0
                )

            elif condition.option == '-':  # Rule: If one field or both is/are empty, ignore condition

                curr_feature[condition.id] = np.where(
                    (
                            (curr_feature[curr_feature_col] >= condition.value) |
                            (curr_feature[curr_feature_col] == -1) |
                            (curr_feature[curr_feature_col] == -2)
                    ), 1, 0
                )

            elif condition.option == '*':  # Rule: If both fields are empty, ignore condition

                curr_feature[condition.id] = np.where(
                    (
                            (curr_feature[curr_feature_col] >= condition.value) |
                            (curr_feature[curr_feature_col] == -2)
                    ), 1, 0
                )

        # Add the current feature column and the condition
        # evaluation flags to the collection of all features.
        features = features.merge(
            curr_feature.drop(columns={"df1", "df2"}),
            on="tuple_ID",
            how="left"
        ).drop_duplicates()

        # Fill nan values with 0 to evade incorrect calculation sums
        # and products of condition evaluation flags.
        features[processed_condition_ids] = features[
            processed_condition_ids
        ].fillna(0)

        # Check if tuples fulfill the relevant conditions
        # for the given feature.
        features["keep"] = np.where(
            features[
                processed_condition_ids
            ].sum(axis=1, skipna=True) >= 1,
            1, 0
        )

        measurements.append_values(
            start=start_time,
            label="match_evaluation_column"
        )

    start_time = time.perf_counter()

    # Aggregate hits on case level: If all conditions of one case
    # are fulfilled, the case is fulfilled.
    for case in matrix.cases:
        features.insert(0, case.id, 0)
        features[case.id] = features[
            case.get_condition_ids()
        ].product(axis=1, skipna=True)

    # Extract match table
    potential_matches = features[
        ['df1', 'df2'] + matrix.get_feature_columns() + matrix.get_case_ids()
        ]

    # Ignore weak cases if stronger case hits
    # This is why the matrix's case array should always
    # comply with structure: Strong -> weak
    for c in range(len(matrix.cases)):
        other_cases = matrix.get_case_ids()
        other_cases.pop(c)
        potential_matches.loc[
            potential_matches[matrix.get_case_ids()[c]] == 1,
            other_cases
        ] = 0

    potential_matches['HitCount'] = potential_matches[
        matrix.get_case_ids()
    ].sum(axis=1, skipna=True)

    measurements.append_values(
        start=start_time,
        label="match_aggregation"
    )

    # write raw result table for this subprocess and set exit_code
    # Only keep tuples with case hit i.e. verified matches.
    return potential_matches.query('HitCount==1').drop(
        columns={"HitCount"}
    )


###################
# HELPERS
###################

def slice_dataframe(df: pd.DataFrame,
                    slice_size: int) -> List[pd.DataFrame]:
    """
     Slices specified pandas.DataFrame or pandas.Series
     into a list of chunks.

    :param df: Input DataFrame to slice.
    :param slice_size: Size of each slice in records. If set to -1,
        only one slice is generated.
    :return: List of slices.
    """

    record_count = df.shape[0]

    # slice size -1 implies passing: No slicing of given frame
    if slice_size <= 0:
        slice_size = df.shape[0]

    slice_count = record_count / slice_size

    slices = []

    for s in range(int(slice_count) + 1):
        if s < int(slice_count):

            slices = slices + [df.iloc[s * slice_size: (s + 1) * slice_size]]

        elif s < slice_count:

            slices = slices + [df.iloc[s * slice_size:]]

    return slices


def safe_match_multiprocess(**kwargs) -> None:
    """
    Executes the match function with defined keyword arguments and
    queues all occurring exception to ensure, that all processes return
    results.

    :param kwargs: Keyword arguments to pass to the match function.
        The argument "queue" MUST be defined.
    """
    try:
        match(**kwargs)
    except Exception as ex:
        queue: Queue = kwargs["queue"]
        queue.put(
            ProcessReturnable(
                matchedTuples=list(),
                tuple_count=0,
                time_measurements=TimeMeasurementCollection(),
                exception=ex
            )
        )


def match_multiprocessing(df1: pd.DataFrame,
                          df2: pd.DataFrame,
                          process_count: int,
                          **kwargs) -> MatchResults:
    """
    Executes the match function in several independent processes. The invocation of
    this method only makes sense, if the executing machine is able to delegate
    processes to multiple cores. If this condition is not fulfilled, the additional
    overhead will slow down the matching process significantly!

    :param df1: Input dataFrame 1. All columns, specified in the neighborhood(s) and
        matrix must be present in this DataFrame as well.
    :param df2: Input dataFrame 2. All columns, specified in the neighborhood(s) and
        matrix must be present in this DataFrame as well.
    :param process_count: Number of processes to execute in parallel. This number cannot exceed 10.
    :param kwargs: Additional arguments, passed to the match function. Please refer to the
        documentation of match().
    :returns: MatchResults object containing all relevant matching information.
    """

    force_intra = False
    if id(df1) == id(df2):
        force_intra = True

    #######################
    sub_process_limit = 10
    #######################

    if process_count <= sub_process_limit:

        # Determine which DataFrame to slice
        slice_df1 = df1.shape[0] >= df2.shape[0]

        # Partition larger DataFrame
        slices = slice_dataframe(
            df=(df1 if slice_df1 else df2),
            slice_size=(df1 if slice_df1 else df2).shape[0] // process_count
        )

    else:
        raise TooManyProcessesException(sub_process_limit)

    procs = []
    queue = Queue()
    proc_num = 1

    # Initialize and start individual subprocesses
    for slc in slices:

        kwargs_proc = dict()
        kwargs_proc.update(kwargs)

        # Build kwargs for the next subprocess
        if slice_df1:
            kwargs_proc.update(
                {
                    "df1": slc,
                    "df2": slice_by_size(df2),
                    "queue": queue,
                    "force_intra": force_intra
                }
            )
        else:
            kwargs_proc.update(
                {
                    "df1": slice_by_size(df1),
                    "df2": slc,
                    "queue": queue,
                    "force_intra": force_intra
                }
            )

        proc = Process(
            target=safe_match_multiprocess,
            kwargs=kwargs_proc
        )

        proc.daemon = True
        proc.start()
        procs.append(proc)
        proc_num += 1

    # Collect returns of each subprocess
    returns: List[ProcessReturnable] = []
    while len(returns) < len(slices):
        returns.append(queue.get())

    # Check for excepted processes
    for rt in returns:
        if rt.exception is not None:
            raise rt.exception

    # Collect time measurements from subprocesses
    measurements_aggr = TimeMeasurementCollection(
        *list(it.chain.from_iterable([rt.time_measurements for rt in returns]))
    )

    # Collect matches from subprocesses
    matched_tuples_aggr = pd.concat(
        list(it.chain.from_iterable([rt.matchedTuples for rt in returns])),
        axis=0
    )

    # Build final MatchResults object
    results = MatchResults(
        matchedTuples=matched_tuples_aggr,
        df1=df1,
        df2=df2,
        matrix=kwargs["matrix"],
        neighborhoods=kwargs["neighborhoods"],
        isIntra=force_intra,
        tuple_count=sum([rt.tuple_count for rt in returns]),
        time_measurements=measurements_aggr
    )

    message_out('! Matching completed !')

    if not _is_intra:
        message_out(
            '<Info> Identified '
            + str(results.matchedTuples.shape[0] * 2)
            + ' unique potential duplicate(s) in DF1 and DF2.'
        )
    else:
        message_out(
            '<Info> Identified '
            + str(results.matchedTuples.shape[0] * 2)
            + ' unique potential duplicate(s) in DF1.'
        )

    return results


def slice_by_size(df: pd.DataFrame) -> List[pd.DataFrame]:
    """
    Slices a given DataFrame into multiple chunks, if
    the DataFrame's size in memory exceeds the limit of 1 GB.

    :param df: DataFrame to evaluate and slice.
    :returns: Array of DataFrame slices.
    """
    if sys.getsizeof(df) >= 10**9:
        slices = slice_dataframe(df, df.shape[0]//2)
        return slices
    else:
        return [df]
