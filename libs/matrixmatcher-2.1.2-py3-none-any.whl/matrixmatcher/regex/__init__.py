from .german_legal_forms import GER_LEGALFORMS
from .german_name_flags import GER_NFLAGS
from .regex_delegation import *
