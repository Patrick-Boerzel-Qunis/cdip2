"""
Contains implementations of all relevant German legal Forms.
"""

from .name_component import LegalForm

# Simple legal forms
####################

gmbh = LegalForm(regex_pattern=(
    "((s?([Gg]esellschaft|[Gg]es\\.)( [Ff](ü|ue)r)?)(\\D*?)([Mm]it [Bb]eschr(ae|ä)nkter "
    "[Hh]aftung|[mM]\\.? ?[bB]\\.? ?[Hh]\\.?))|([Gg]\\.? ?[mM]\\.? ?[bB]\\.? ?[Hh]\\.?)"
), standard_name='GmbH', replace_groups=[2, 7, 9])

kg = LegalForm(regex_pattern=(
    "(?<=\\.| )([Kk]\\.? ?[Gg]\\.? ?)(?= |$|&|,)|[Kk]ommandit(gesellschaft|ges\\.)"
), standard_name='KG', composite_pos=2)

ohg = LegalForm(regex_pattern=(
    "(?<= |\\.)([Oo]ffene ?|[Oo]\\.? ?)([Hh]andel(s?) ?|[Hh]\\.? ?)([Gg]esellschaft|[Gg]es.|[Gg]\\.? ?)"
), standard_name='oHG')

partg = LegalForm(regex_pattern=(
    "[Pp]art[Gg]|[Pp]artnerschafts(gesellschaft|ges\\.)"
), standard_name='PartG')

gbr = LegalForm(regex_pattern=(
    "[Gg]\\.? ?[Bb]\\.? ?[Rr]\\.?(?= |$|&|,)|([Gg]esellschaft|[Gg]es\\.) "
    "([Bb](ue|ü)rgerlichen|[Bb](ue|ü)rg\\.|[Bb]\\.?) ?([Rr]echts|[R]\\.?)"
), standard_name='GbR')

wv = LegalForm(regex_pattern=(
    "(?<= )[Ww]\\.? ?[Vv]\\.? ?(?= |$|&|,)|[Ww]irtschaftlicher [Vv]erein"
), standard_name='w.V.')

ag = LegalForm(regex_pattern=(
    "(?<= )[Aa]\\.?[Gg]\\.? ?(?= |$|&|,)|[Aa]ktien(gesellschaft|ges\\.)"
), standard_name='AG')

ek = LegalForm(regex_pattern=(
    "(?<= )[Ee](\\.|(\\. ))?[Kk]\\.? ?(?= |$|&|,)|[Ee]ingetragener (\\D*)? ?[Kk]aufmann"
), standard_name='e.K.', extends=[ohg.standard_name, ag.standard_name])

ekfr = LegalForm(regex_pattern=(
    "(?<= )[Ee](\\.|(\\. ))?[Kk][Ff][Rr]\\.? ?(?= |$|&|,)|[Ee]ingetragene (\\D*)? ?[Kk]auffrau"
), standard_name='e.Kfr.', extends=[ohg.standard_name, ag.standard_name, ek.standard_name])

ev = LegalForm(regex_pattern=(
    "(?<= )[Ee](\\.|(\\. ))?[Vv]\\.? ?(?!\\D*[Kk]irche|"
    "\\D*[Kk]inder|\\D*[Kk]ranken)(?= |$|&|,)|[Ee]ingetragener [Vv]erein"
), standard_name='e.V.', extends=[ag.standard_name, gmbh.standard_name])

ug = LegalForm(regex_pattern=(
    "((?<= )[Uu](\\.|(\\. ))?[Gg]\\.? ?(?= |$|&|\\()|[Uu]nternehmer(gesellschaft|ges\\.))"
    " ?(\\(?[Hh]aftungsbeschr(ä|ae)nkt\\)?)?"
), standard_name='UG (Haftungsbeschränkt)', extends=[gmbh.standard_name])

ltd = LegalForm(regex_pattern=(
    "(?<= |\\.)[Ll]td\\.?|(?<![Uu]n)[Ll]imited"
), standard_name='Ltd.')

vvag = LegalForm(regex_pattern=(
    "[Vv]\\.?[Vv]\\.?[Aa]\\.?[Gg]\\.? ?|[Vv]ersicherung [Aa]uf [Gg]egenseitigkeit"
), standard_name='VVaG', extends=[ag.standard_name])

ador = LegalForm(regex_pattern=(
    "(?<= )[Aa]\\.? ?[Dd]?\\.? ?[Öö]\\.? ?[Rr]\\.?|[Aa]nstalt ([Dd]es)? ?([Öö]|[Oo]e)ffentlichen [Rr]echts"
), standard_name='AdöR')

eg = LegalForm(regex_pattern=(
    "(?<= )([Ee](\\.|(\\. ))?[Gg]\\.?)(?= |$|&|,)|[Ee]ingetragene [Gg]enossenschaft"
), standard_name='e.G.')

sdor = LegalForm(regex_pattern=(
    "(?<= )[Ss]\\.? ?[Dd]\\.? ?[Öö]\\.? ?[Rr]\\.? ?|[Ss]tiftung ([Dd]es)? ?([Öö]|[Oo]e)ffentlichen [Rr]echts"
), standard_name='SdöR')

sdpr = LegalForm(regex_pattern=(
    "(?<= )[Ss]\\.? ?[Dd]\\.? ?[Pp]\\.? ?[Rr]\\.? ?|[Ss]tiftung ([Dd]es)? ?[Pp]rivaten [Rr]echts"
), standard_name='SdpR')

ewiv = LegalForm(regex_pattern=(
    ("(?<= )[Ee]\\.? ?[Ww]\\.? ?[Ii]\\.? ?[Vv]\\.?(?= |$|&|,)|[Ee]urop(ä|ae)ische"
     " [Ww]irtschaftliche [Ii]nteressenvereinigung")
), standard_name='EWIV')

se = LegalForm(regex_pattern=(
    "(?<= )[Ss]\\.?[Ee]\\.? ?(?= |$|&|,)|[Ss]ocietas [Ee]uropaea"
), standard_name='SE')

sce = LegalForm(regex_pattern=(
    "((?<= )[Ss]\\.? ?[Cc]\\.? ?[Ee]\\.?(?= |$|&|,)|[Ss]ocietas [Cc]ooperativa [Ee]uropaea)"
    "( ?[Mm]it [Bb]eschr(ae|ä)nkter [Hh]aftung| ?[mM]\\.? ?[bB]\\.? ?[Hh]\\.?)"
), standard_name='SCE')

meg = LegalForm(regex_pattern=(
    "(?<= )[Mm]\\.? ?[Ee]\\.? ?[Gg]\\.? ?(?= |$|&|,)|[Mm]iteigentumsgemeinschaft"
), standard_name='MG')

# Modified forms
#################

ggmbh = LegalForm(regex_pattern=(
        "(([Gg]emeinn(ü|ue)tzige)(\\D*?)" + '(' + gmbh.regex_pattern + '))' +
        "|([Gg]\\.?[Gg]\\.?[mM]\\.?[bB]\\.?[Hh]\\.?)"
), standard_name='gGmbH', extends=[gmbh.standard_name], replace_groups=[2, 7, 12, 14, 15])

gmbhig = LegalForm(regex_pattern=(
        '(' + gmbh.regex_pattern + ')' + " ?([Ii]\\.? ?[Gg]\\.? ?|[Ii]n [Gg]r(ue|ü)ndung)"
), standard_name='GmbH i. G.', extends=[gmbh.standard_name])

ggmbhig = LegalForm(regex_pattern=(
        '(' + ggmbh.regex_pattern + ')' + " ?([Ii]\\.? ?[Gg]\\.? ?|[Ii]n [Gg]r(ue|ü)ndung)"
), standard_name='gGmbH i. G.', extends=[
    gmbh.standard_name, gmbhig.standard_name, ggmbh.standard_name
], replace_groups=[3, 8, 12, 15, 16])

kgaa = LegalForm(regex_pattern=(
    "(?<=\\.| )(([Kk]\\.? ?[Gg]\\.? ?|[Kk]ommandit(gesellschaft|ges\\.))(( ?[aA](uf)?\\.?) ?[aA](ktien)?\\.? ?))"
), standard_name='KGaA', extends=[kg.standard_name], composite_pos=2)

gag = LegalForm(regex_pattern=(
    "([Gg]emeinn(ü|ue)tzige | g\\.?)( ?[Aa]\\.? ?[Gg]\\.? ?(?= |$|&|\\.)|[Aa]ktien(gesellschaft|ges\\.))"
), standard_name='gAG', extends=[ag.standard_name])

gbrmbh = LegalForm(regex_pattern=(
        '(' + gbr.regex_pattern + ')' +
        " ?(([mM]\\.? ?[bB]\\.? ?[Hh]\\.? ?|[Mm]it [Bb]eschr(ae|ä)nkter [Hh]aftung))"
), standard_name='GbR mbH', extends=[gbr.standard_name, gmbh.standard_name])

partgmbh = LegalForm(regex_pattern=(
        '(' + partg.regex_pattern + ')' + " ?([Mm]\\.? ?[Bb]\\.? ?([Hh]|[Bb])\\.?)?"
), standard_name='PartG mbH', extends=[partg.standard_name, gmbh.standard_name])

# Mixed legal forms
####################

mixmarker = LegalForm(regex_pattern=(
    "(&|und|\\+) ?[Cc][oO]\\.?"
), standard_name='& Co.', standalone=False, composite_pos=1)

########################
# CONSOLIDATION
########################

GER_LEGALFORMS = [
    gmbh,
    kg,
    ohg,
    partg,
    gbr,
    ev,
    wv,
    ek,
    ekfr,
    ag,
    ug,
    ltd,
    vvag,
    ador,
    eg,
    sdor,
    sdpr,
    ewiv,
    se,
    sce,
    meg,
    ggmbh,
    gmbhig,
    ggmbhig,
    kgaa,
    gag,
    gbrmbh,
    partgmbh,
    mixmarker
]
