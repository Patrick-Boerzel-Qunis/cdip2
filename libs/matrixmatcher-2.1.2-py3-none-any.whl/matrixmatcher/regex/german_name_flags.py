"""
Contains implementations of all relevant German name flags.

Flag categories:
'NLB' := Non-locality based
'LB' := Locality based
"""

from dataclasses import dataclass
import re

from .name_component import NameFlag
from ..utils.string_standardization import standardize_umlauts, remove_separator_characters


#######################
# IMPLEMENTATIONS
#######################


# Interpreters
##################

def interpretDirection(str_: str) -> str:
    """
    Standardizes a direction string.
    (German language version)

    Keyword Arguments:
    str_ : Input string
    """

    return remove_separator_characters(
        standardize_umlauts(str_).strip()
    ).lower().replace(' ', '')


def parse_int_from_text_ger(str_: str) -> int:
    """
    Parses integers from a natural language string.
    (German language version)

    Keyword Arguments:
    str_ : Input string
    """

    str_ = str_.strip()

    if not str_:
        return 0

    try:
        num = float(str_) if float(str_) < 1000 else 0
        return int(num)
    except (ValueError, TypeError):
        ...

    @dataclass
    class Element:
        regex: str
        transl: int

    @dataclass
    class Base:
        elements: list
        label: str
        rank: int

    pref_bx = "(^|hundert|und)"
    suff_bx = "(und| |$|te)"

    base_x = Base([
        Element(pref_bx + '([Ee]in(s)?|[Ee]rs)' + suff_bx, 1),
        Element(pref_bx + '([Zz]wei)' + suff_bx, 2),
        Element(pref_bx + '([Dd]rei|[Dd]rit)' + suff_bx, 3),
        Element(pref_bx + '([Vv]ier)' + suff_bx, 4),
        Element(pref_bx + '([Ff](ü|ue)nf)' + suff_bx, 5),
        Element(pref_bx + '([Ss]echs)' + suff_bx, 6),
        Element(pref_bx + '([Ss]ieb|[Ss]ieben)' + suff_bx, 7),
        Element(pref_bx + '([Aa]ch(t)?)' + suff_bx, 8),
        Element(pref_bx + '([Nn]eun)' + suff_bx, 9),
    ], 'bx', 1)

    pref_b1x = "(^|hundert|tausend)"
    suff_b1x = "(und| |$|te)"

    base_1x = Base([
        Element(pref_b1x + '([Zz]ehn)' + suff_b1x, 10),
        Element(pref_b1x + '([Ee]lf)' + suff_b1x, 11),
        Element(pref_b1x + '([Zz]w(ö|oe)lf)' + suff_b1x, 12),
        Element(pref_b1x + '([Dd]reizehn)' + suff_b1x, 13),
        Element(pref_b1x + '([Vv]ierzehn)' + suff_b1x, 14),
        Element(pref_b1x + '([Ff](ü|ue)nfzehn)' + suff_b1x, 15),
        Element(pref_b1x + '([Ss]echzehn)' + suff_b1x, 16),
        Element(pref_b1x + '([Ss]iebzehn)' + suff_b1x, 17),
        Element(pref_b1x + '([Aa]chtzehn)' + suff_b1x, 18),
        Element(pref_b1x + '([Nn]eunzehn)' + suff_b1x, 19),
    ], 'b1x', 2)

    pref_bx0 = "(^|und|hundert|tausend)"
    suff_bx0 = "( |$|ste)"

    base_x0 = Base([
        Element(pref_bx0 + '([Zz]wanzig)' + suff_bx0, 20),
        Element(pref_bx0 + '([Dd]rei(ß|ss)ig)' + suff_bx0, 30),
        Element(pref_bx0 + '([Vv]ierzig)' + suff_bx0, 40),
        Element(pref_bx0 + '([Ff](ü|ue)nfzig)' + suff_bx0, 50),
        Element(pref_bx0 + '([Ss]echzig)' + suff_bx0, 60),
        Element(pref_bx0 + '([Ss]iebzig)' + suff_bx0, 70),
        Element(pref_bx0 + '([Aa]chtzig)' + suff_bx0, 80),
        Element(pref_bx0 + '([Nn]eunzig)' + suff_bx0, 90),
    ], 'bx0', 3)

    pref_bx00 = "(^|tausend)"
    suff_bx00 = ""

    base_x00 = Base([
        Element(pref_bx00 + '([Ee]inhundert)' + suff_bx00, 100),
        Element(pref_bx00 + '([Zz]weihundert)' + suff_bx00, 200),
        Element(pref_bx00 + '([Dd]reihundert)' + suff_bx00, 300),
        Element(pref_bx00 + '([Vv]ierhundert)' + suff_bx00, 400),
        Element(pref_bx00 + '([Ff](ü|ue)nfhundert)' + suff_bx00, 500),
        Element(pref_bx00 + '([Ss]echshundert)' + suff_bx00, 600),
        Element(pref_bx00 + '([Ss]iebenhundert)' + suff_bx00, 700),
        Element(pref_bx00 + '([Aa]chthundert)' + suff_bx00, 800),
        Element(pref_bx00 + '([Nn]eunhundert)' + suff_bx00, 900),
    ], 'bx00', 4)

    pref_bx000 = ""
    suff_bx000 = ""

    base_x000 = Base([
        Element(pref_bx000 + '([Ee]intausend)' + suff_bx000, 1000),
        Element(pref_bx000 + '([Zz]weitausend)' + suff_bx000, 2000),
        Element(pref_bx000 + '([Dd]reitausend)' + suff_bx000, 3000),
        Element(pref_bx000 + '([Vv]iertausend)' + suff_bx000, 4000),
        Element(pref_bx000 + '([Ff](ü|ue)nftausend)' + suff_bx000, 5000),
        Element(pref_bx000 + '([Ss]echstausend)' + suff_bx000, 6000),
        Element(pref_bx000 + '([Ss]iebentausend)' + suff_bx000, 7000),
        Element(pref_bx000 + '([Aa]chttausend)' + suff_bx000, 8000),
        Element(pref_bx000 + '([Nn]euntausend)' + suff_bx000, 9000),
    ], 'bx000', 5)

    # Parsing
    ###########

    num = 0
    for base in [base_x, base_1x,
                 base_x0, base_x00, base_x000]:
        i = [e.transl for e in base.elements
             if re.search(e.regex, str_)]

        num = num + i[0] if len(i) > 0 else num

    return num


# NAME FLAGS
##################

# Special case: Numbers
######

compiled_bx = ("((?=^|hundert|und)|(?<= ))(([Ee]in(s)?|[Ee]rs)|([Zz]wei)|([Dd]rei|[Dd]rit)|([Vv]ier)|"
               "([Ff](ü|ue)nf)|([Ss]echs)|([Ss]ieb|[Ss]ieben)|([Aa]ch(t)?)|([Nn]eun))(^|hundert|und| |$|te)")

complied_b1x = ("((?=^|hundert|tausend)|(?<= ))(([Zz]ehn)|([Ee]lf)|([Zz]w(ö|oe)lf)|([Dd]reizehn)|"
                "([Vv]ierzehn)|([Ff](ü|ue)nfzehn)|([Ss]echszehn)|([Ss]iebzehn)|([Aa]chtzehn)|"
                "([Nn]eunzehn))(und| |$|te)")

compiled_bx0 = ("((?=^|und|hundert|tausend)|(?<= ))(([Zz]wanzig)|([Dd]rei(ß|ss)ig)|([Vv]ierzig)|"
                "([Ff](ü|ue)nfzig)|([Ss]echszig)|([Ss]iebzig)|([Aa]chtzig)|([Nn]eunzig))( |$|ste)")

compiled_bx00 = ("(^|tausend)(([Ee]inhundert)|([Zz]weihundert)|([Dd]reihundert)|([Vv]ierhundert)|"
                 "([Ff](ü|ue)nfhundert)|([Ss]echshundert)|([Ss]iebenhundert)|([Aa]chthundert)|([Nn]eunhundert))")

compiled_bx000 = ("(([Ee]intausend)|([Zz]weitausend)|([Dd]reitausend)|([Vv]iertausend)|([Ff](ü|ue)nftausend)"
                  "|([Ss]echstausend)|([Ss]iebentausend)|([Aa]chttausend)|([Nn]euntausend))")

compiled_reg_num = (
        "((^|(?<= |-))\\d+( )?(?=$|\\. |-|[Gg]|[Aa]|[Kk]|[Vv])|((?<=\\. )|(?<=\\.))\\d+)|"  # Digits 0-9
        + "(([a-zA-Zäßüö]+)?((" + compiled_bx + ")|(" + complied_b1x + ")|("
        + compiled_bx0 + ")|(" + compiled_bx00 + ")|(" + compiled_bx000
        + "))([a-zA-Zäßüö]+)?)"
)

number = NameFlag(
    regex_pattern=compiled_reg_num,
    standard_name='Number',
    interpret_as_bool=False,
    custom_interpreter=parse_int_from_text_ger,
    category={"NLB"}
)

######

service = NameFlag(
    regex_pattern="(( |-|^|\\.|~|\\+|&)[Ss]ervice(s)?|[Dd]ienstl(eistung(s|en))?)(?= |$|-|ges|\\.)",
    standard_name='Service',
    category={"NLB"}
)

admin = NameFlag(
    regex_pattern=("(( |-|^|\\.|~|\\+|&|[Gg]rundst(ü|ue)ck(s)?|[Vv]erm(ö|oe)gen(s)?|"
                   "[Ii]mmobilien)[Vv]erwaltung(s)?|[Aa]dministration(s)?)(?= |$|-|ges|amt)"),
    standard_name='Administration',
    category={"NLB"}
)

holding = NameFlag(
    regex_pattern="([Hh]olding)",
    standard_name='Holding',
    category={"NLB"}
)

sales = NameFlag(
    regex_pattern="([Vv]ertrieb(s)?|[Ss]ales)(?= |$|-|ges)",
    standard_name='Sales',
    category={"NLB"}
)

invest = NameFlag(
    regex_pattern="([Bb]eteiligung(en|s)?|[Ii]nvestment)(?= |$|-|(kommandit)?ges)",
    standard_name='Investment',
    category={"NLB"}
)

direction = NameFlag(
    regex_pattern=("( |-|^|\\.|~|\\+|&)(([Nn]ord|[Ss](ü|ue)d)((-| |\\.|\\/)?([Ww]est|[Oo]st))?|"
                   "(([Nn]ord|[Ss](ü|ue)d))?(-| |\\.|\\/)?([Ww]est|[Oo]st))(?= |$|-|\\/)"),
    standard_name='Direction',
    interpret_as_bool=False,
    custom_interpreter=interpretDirection,
    category={"LB"}
)

prop = NameFlag(
    regex_pattern="([Gg]rundstück|[Gg]rundstueck)",
    standard_name='Property',
    category={"NLB"}
)

board = NameFlag(
    regex_pattern="( |-|^|\\.|~|\\+|&)([Gg]esch(ä|ae)ftsf(ü|ue)hrung(s)?)(?= |$|-|ges)",
    standard_name='Management board',
    category={"NLB"}
)

trade = NameFlag(
    regex_pattern="( |-|^|\\.|~|\\+|&)([Tt]rading|[Hh]andels)(?= |$|-|ges)",
    standard_name='Trading',
    category={"NLB"}
)

fedState = NameFlag(
    regex_pattern=("([Hh]essen|[Bb]ayern|[Tt]h(ü|ue)ringen|[Nn]ordrhein(-| )[Ww]estfalen|[Bb]erlin|[Hh]amburg|"
                   "([Nn]ieder)?[Ss]achsen((-| )[Aa]nhalt)?|[Ss]aarland|[Bb]remen|[Ss]chleswig(-| )[Hh]olstein|"
                   "[Rr]heinland(-| )[Pp]falz|[Bb]aden(-| )[Ww](ü|ue)rttemberg|[Mm]ecklenburg(-| )[Vv]orpommern|"
                   "[Bb]randenburg)(?= |$|-|er|ische)"),
    standard_name='Federal state',
    interpret_as_bool=False,
    custom_interpreter=standardize_umlauts,
    category={"LB"}
)

church = NameFlag(
    regex_pattern="([Kk]irchengemeinde)",
    standard_name='Church',
    category={"NLB"}
)

########################
# CONSOLIDATION
########################

GER_NFLAGS = [
    number,
    service,
    admin,
    holding,
    sales,
    invest,
    direction,
    prop,
    board,
    trade,
    fedState,
    church
]
