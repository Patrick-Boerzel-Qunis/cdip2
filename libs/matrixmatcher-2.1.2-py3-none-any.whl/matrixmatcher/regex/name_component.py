"""
Wraps classes: NameComponent, LegalForm, CompanyType
"""

import re
from abc import ABCMeta, abstractmethod
from typing import List


class NameComponent(object, metaclass=ABCMeta):
    """
    (ABSTRACT BASE)
    Summarizes a generic name component's definitions.
    """

    def __init__(self,
                 regex_pattern: str,
                 standard_name: str,
                 replace_groups: List[int] = None):
        """
        Constructs NameComponent.

        :param regex_pattern: Regex pattern to identify the component
            within company names. The pattern should only match the desired
            component, not other parts of the name.
        :param standard_name: Standardized name of the component. This can be
            the standard name of a legal form or any other unique identifier.
        :param replace_groups: List of regex match groups, that can be extracted and
            replaced with an empty string in order to isolate the component.
            Choose one or multiple integer regex match groups (default: all groups).
        """

        self.regex_pattern = regex_pattern
        self.standard_name = standard_name
        self.replace_groups = replace_groups

    def __eq__(self, other):
        return self.standard_name == other.standard_name

    def __hash__(self):
        return hash(self.standard_name + self.regex_pattern)

    # GETTER
    ##################

    @property
    def regex_pattern(self) -> str:
        return self._regex_pattern

    @property
    def standard_name(self) -> str:
        return self._standard_name

    @property
    def replace_groups(self) -> List[int]:
        return self._replace_groups

    # SETTER
    ##################

    @regex_pattern.setter
    def regex_pattern(self, regex_pattern: str) -> None:
        self._regex_pattern = regex_pattern

    @standard_name.setter
    def standard_name(self, standard_name: str) -> None:
        self._standard_name = standard_name

    @replace_groups.setter
    def replace_groups(self, replace_groups) -> None:
        self._replace_groups = replace_groups

    # LOGIC
    ##################

    @abstractmethod
    def search_in_name(self, c_name: str) -> dict:
        """
        Identifies the component in an arbitrary company name.

        :param c_name: Full company name.
        :return: Truth value (component present?), the component's
            standard name and further information on the match.
        """
        ...

    @abstractmethod
    def extract_from_name(self, c_name: str) -> List[str]:
        """
        Identifies AND extracts the component in an
        arbitrary company name.

        :param c_name: Full company name.
        :return: Isolated company name (index 0) as well as
            the extracted component (index 1).
        """
        ...


##############################
# INHERITANCE
##############################

class LegalForm(NameComponent):
    """
    Summarizes a legal form's definitions.
    Implements class NameComponent
    """

    def __init__(self, regex_pattern: str,
                 standard_name: str,
                 extends: List[str] = None,
                 replace_groups: List[int] = None,
                 standalone: bool = True,
                 composite_pos: int = 0):
        """
        Constructs LegalForm.

        :param regex_pattern: Regex pattern to identify the component
            within company names. The pattern should only match the desired
            component, not other parts of the name.
        :param standard_name: Standardized name of the component. This can be
            the standard name of a legal form or any other unique identifier.
        :param replace_groups: List of regex match groups, that can be extracted and
            replaced with an empty string in order to isolate the component.
            Choose one or multiple integer regex match groups (default: all groups).
        :param extends: If this legal form overrides another one (parent),
            set the parent legal form's standardName.This can happen in various scenarios.
            E.g.: "ABC gGmbH" -> "gGmbH" regex pattern will also provoke a match on "GmbH".
            Hence, it is necessary to disregard the match on "GmbH", if there is a match with "gGmbH".
            As a result, the legal form "gGmbh" must extend the legal form "GmbH".
        :param standalone: Can the legal form be independent of other legal forms? E.g.: "GmbH" can be
            standalone, while "Co." cannot.
        :param composite_pos: Marks the position of this legal form within a company name with multiple
            legal form components. 0: First position, 1: Second position, 2: Third position.
            (E.g.: "ABC GmbH & Co. KGaA" -> "GmbH" has position 0, "& Co." has
            position 1 and "KGaA" has position 2).
        """

        super(LegalForm, self).__init__(
            regex_pattern, standard_name, replace_groups
        )

        self.extends = extends
        self.standalone = standalone
        self.composite_pos = composite_pos

    # GETTER
    ##################

    @property
    def extends(self) -> List[str]:
        return self._extends

    @property
    def standalone(self) -> bool:
        return self._standalone

    @property
    def composite_pos(self) -> int:
        return self._composite_pos

    # SETTER
    ##################

    @extends.setter
    def extends(self, extends: List[str]) -> None:
        self._extends = extends

    @standalone.setter
    def standalone(self, standalone: bool) -> None:
        self._standalone = standalone

    @composite_pos.setter
    def composite_pos(self, composite_pos: int) -> None:
        self._composite_pos = composite_pos

    # LOGIC
    ##################

    def search_in_name(self, c_name: str) -> dict:
        """
        Identifies the legal form in an arbitrary company name.

        :param c_name: Full company name.
        :return: Truth value (legal form present?), the legal form's
            standard name and override information.
        """
        return (
            {'standard_name': self.standard_name,
             'present': True, 'overrides': self._extends}
            if c_name and re.search(self.regex_pattern, c_name) else
            {'standard_name': self.standard_name,
             'present': False, 'overrides': None}
        )

    def extract_from_name(self, c_name: str) -> List[str]:
        """
        Identifies AND extracts the legal form in an
        arbitrary company name.

        :param c_name: Full company name.
        :return: Isolated company name (index 0) as well as
            the extracted legal form (index 1).
        """

        extraction = (
            self.standard_name
            if re.search(self.regex_pattern, c_name) else
            None
        )

        if extraction:

            if not self.replace_groups:  # Replace all capture groups

                c_name = re.sub(
                    self.regex_pattern, '', c_name
                ).replace('  ', ' ')

            else:  # Replace only selected capture groups

                c_name_pers = c_name

                for rg in self._replace_groups:
                    rg_str = re.search(self.regex_pattern, c_name_pers)[rg]
                    c_name = c_name.replace(
                        rg_str if rg_str else '', ''
                    ).strip().replace('  ', ' ')

        return [c_name, extraction]


class NameFlag(NameComponent):
    """
    Summarizes a name flag's definitions.
    Implements class NameComponent.
    """

    def __init__(self,
                 regex_pattern: str,
                 standard_name: str,
                 category: set,
                 replace_groups: List[int] = None,
                 interpret_as_bool: bool = True,
                 custom_interpreter: callable = None):
        """
        Constructs NameFlag.

        :param regex_pattern: Regex pattern to identify the component
            within company names. The pattern should only match the desired
            component, not other parts of the name.
        :param standard_name: Standardized name of the component. This can be
            the standard name of a legal form or any other unique identifier.
        :param replace_groups: List of regex match groups, that can be extracted and
            replaced with an empty string in order to isolate the component.
            Choose one or multiple integer regex match groups (default: all groups).
        :param category: Category of the given flag. The flag can either join an existing
            category or constitute a new one. The category should be chosen with care.
        :param interpret_as_bool: Is the flag interpretable as a boolean value or are
            more than two expressions possible?
        :param custom_interpreter: Customized interpreter that extracts and standardizes
            the flag within an arbitrary company name. The interpreter must take exactly one
            positional string argument (regex match) and must return exactly one interpreted
            value of any type.
        """

        super(NameFlag, self).__init__(
            regex_pattern, standard_name, replace_groups
        )

        self.interpret_as_bool = interpret_as_bool
        self.custom_interpreter = custom_interpreter
        self.category = category

    # GETTER
    ##################

    @property
    def interpret_as_bool(self) -> bool:
        return self._interpret_as_bool

    @property
    def custom_interpreter(self) -> callable:
        return self._custom_interpreter

    @property
    def category(self) -> set:
        return self._category

    # SETTER
    ##################

    @interpret_as_bool.setter
    def interpret_as_bool(self, interpret_as_bool: bool) -> None:
        self._interpret_as_bool = interpret_as_bool

    @custom_interpreter.setter
    def custom_interpreter(self, custom_interpreter: callable) -> None:
        self._custom_interpreter = custom_interpreter

    @category.setter
    def category(self, category: set):
        self._category = category

    # LOGIC
    ##################

    def search_in_name(self, c_name) -> dict:
        """
        Identifies the name flag in an arbitrary company name.

        :param c_name: Full company name.
        :return: The name flag's standard name as well as the
            extracted and interpreted value. For boolean flags, the
            value will always be boolean.
        """

        try:
            extract = re.search(self.regex_pattern, c_name)[0]
        except TypeError:
            extract = None

        if extract:
            if self._interpret_as_bool:
                return {'standard_name': self.standard_name,
                        'value': True}

            else:
                if not self.custom_interpreter:
                    return {'standard_name': self.standard_name,
                            'value': extract}
                else:
                    return {'standard_name': self.standard_name,
                            'value': self.custom_interpreter(extract)}
        else:
            return {'standard_name': self.standard_name,
                    'value': False}

    def extract_from_name(self, c_name: str) -> List[str]:
        pass
