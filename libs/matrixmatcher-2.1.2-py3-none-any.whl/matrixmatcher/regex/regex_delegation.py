"""
Contains functions and logic to delegate tasks
to the appropriate regex collections.
"""

from typing import List
import pandas as pd

from .german_legal_forms import GER_LEGALFORMS
from .german_name_flags import GER_NFLAGS
from ..core.exceptions import InvalidCommandException
from ..utils.system import deprecation_warning_alias


def flag_additional_information(c_name: str, category: set = None) -> dict:
    """
    Identifies all name flags (within the name flag collection) in an
    arbitrary company name. The flags can be filtered by category.
    The default collection is GER_NFLAGS (German name flags).

    :param c_name: Arbitrary full company name.
    :param category: Set to True to select all available categories
        or choose specific categories. The specific categories can vary
        throughout the implementations. Use RegexDelegator.get_flag_categories()
        to get a complete list of all available categories.
    :return: Dictionary with all name flags' standard names as keys and the
        interpreted value (if present in the company name) as the dictionary's values.
        E.g.: {"trade": True, "direction": "west", "investment": False, ...}
    """

    if category:
        if not all([cat in get_flag_categories() for cat in category]):
            raise InvalidCommandException(
                "category",
                list(get_flag_categories()) + ["bool"]
            )

    # NAME FLAG COLLECTION
    #########################################
    if category is None:
        nf_collection = GER_NFLAGS
    else:
        nf_collection = [
            nf for nf in GER_NFLAGS if [
                cat for cat in nf.category if cat in list(category)
            ]
        ]
    #########################################

    res = {}

    for nf in nf_collection:
        res_ = nf.search_in_name(c_name)
        res[res_['standard_name']] = res_['value']

    return res


def get_flag_categories() -> set:
    """
    Returns all implemented name flag categories
    in the name flag collection. The default collection
    is GER_NFLAGS (German name flags).

    :return: Labels of all categories as a list.
    """

    # NAME FLAG COLLECTION
    #########################################
    nf_collection = GER_NFLAGS
    #########################################

    return {
        cat for sub in
        [list(nf.category) for nf in nf_collection]
        for cat in sub
    }


def identify_legal_form_in_name(c_name: str) -> List[str]:
    """
    Identifies all legal forms (within the legal form collection) in an
    arbitrary company name and returns the isolated company name as well
    as the identified legal forms' standard names. The default collection
    is GER_LEGALFORMS (German legal forms).

    :param c_name: Arbitrary full company name.
    :return: List with the isolated company name at index 0 and the
        compiled identified legal forms' standard names at index 1.
        E.g.: "ABC GmbH & Co. KG" -> ["ABC", "GmbH & Co. KG"]
    """

    # LEGAL FORM COLLECTION
    #########################################
    lf_collection = GER_LEGALFORMS
    #########################################

    exception_values = {
        "ERROR": "Error",
        "NOT_FOUND": "NoF",
        "MULTIPLE": "Multiple"
    }

    res = []

    for lf in lf_collection:  # Identify legal form
        res_ = lf.search_in_name(c_name)
        if res_['present']:
            res.append(res_)

    for res_ in res:  # Remove overridden legal forms
        if res_['overrides']:
            res = [
                lf_ for lf_ in res if lf_["standard_name"] not in res_['overrides']
            ]

    extracted = [res_['standard_name'] for res_ in res]
    extracted_lfs = [lf for lf in lf_collection if lf.standard_name in extracted]

    for lf in extracted_lfs:
        c_name = lf.extract_from_name(c_name)[0].strip()

    # Build composite string

    composite0 = [lf.standard_name for lf
                  in extracted_lfs if lf.composite_pos == 0]
    composite1 = [lf.standard_name for lf
                  in extracted_lfs if lf.composite_pos == 1]
    composite2 = [lf.standard_name for lf
                  in extracted_lfs if lf.composite_pos == 2]

    composite_str = exception_values["ERROR"]  # Error value, if no case returns a result (unexpected error)

    if len(composite1) == 0:
        if len(composite0) == 1 and len(composite2) == 0:
            composite_str = composite0[0]
        elif len(composite2) == 1 and len(composite0) == 0:
            composite_str = composite2[0]
        elif len(composite0) == 0 and len(composite2) == 0:
            composite_str = exception_values["NOT_FOUND"]
        else:
            composite_str = exception_values["MULTIPLE"]

    if len(composite1) >= 1:
        if len(composite0) == 1 or len(composite2) == 1:
            composite_str = (
                    (composite0[0] if len(composite0) == 1 else '') + ' '
                    + (composite1[0] if len(composite2) == 1 else '') + ' '
                    + (composite2[0] if len(composite2) == 1 else '')
            ).strip()
        elif len(composite0) == 2:
            composite_str = (
                    composite0[0] + ' '
                    + composite1[0] + ' '
                    + composite0[1]
            )
        elif len(composite2) == 2:
            composite_str = (
                    composite2[0] + ' '
                    + composite1[0] + ' '
                    + composite2[1]
            )
        elif len(composite0) == 0 and len(composite2) == 0:
            composite_str = exception_values["NOT_FOUND"]
        else:
            composite_str = exception_values["MULTIPLE"]

    return [c_name, composite_str]


def extract_legal_forms(ser_in: pd.Series) -> pd.DataFrame:
    """
    Identifies all legal forms (within the legal form collection) in all supplied
    company name and returns the isolated company names as well as the identified
    legal forms' standard names as a pandas.DataFrame. The default collection
    is GER_LEGALFORMS (German legal forms).

    :param ser_in: Pandas.Series object with arbitrary full company names.
    :return: pandas.DataFrame with the isolated company name in column "company_name"
        and the compiled identified legal forms' standard names in column "legal_form"
    """

    res = ser_in.apply(
        lambda x: '|'.join(identify_legal_form_in_name(x))
    )

    return pd.DataFrame(
        {'company_name': res.str.split('|').str[0],
         'legal_form': res.str.split('|').str[1]}
    )


#############
# DEPRECATION
#############

@deprecation_warning_alias("identify_legal_form_in_name")
def identifyLegalFormInCompanyName(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'identify_legal_form_in_name'.
    """
    return identify_legal_form_in_name(*args, **kwargs)


@deprecation_warning_alias("extract_legal_forms")
def extractLegalForms(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'extract_legal_forms'.
    """
    return extract_legal_forms(*args, **kwargs)


@deprecation_warning_alias("get_flag_categories")
def getNameFlagCategories():
    """
    Deprecated function name.
    Please refer to name 'get_flag_categories'.
    """
    return get_flag_categories()


@deprecation_warning_alias("flag_additional_information")
def flagAdditionalInformation(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'flag_additional_information'.
    """
    return flag_additional_information(*args, **kwargs)
