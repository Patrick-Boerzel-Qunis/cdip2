"""
Contains functions for string standardization.
"""

import unicodedata as uc


def standardize_umlauts(str_: str) -> str:
    """
    Standardizes all German umlauts for one input string and
    converts them into ASCII characters. E.g.: "ä" -> "ae"

    :param str_: input string.
    :return: Input string with standardized umlauts.
    """
    return str_.replace('ü', 'ue').replace(
        'ö', 'oe').replace('ä', 'ae').replace('ß', 'ss')


def remove_separator_characters(str_: str) -> str:
    """
    Removes special separator characters from one input string.
    E.g.: "Abc,def;ghi|jkl" -> "Abcdefghijkl"

    Includes characters: , ';' '/' '\' '-' '|' '.'

    :param str_: input string.
    :param: Input string without separator characters.
    """
    return str_.replace(',', '').replace(';', '').replace('/', '').replace(
        '\\', '').replace('-', '').replace('|', '').replace('.', '')


def normalize_unicode_characters(str_: str) -> str:
    """
    Removes and standardizes uninterpreted
    unicode characters.

    :param str_: Input string
    :return: Input string with standardized unicode
        characters.
    """
    return uc.normalize('NFKD', str_)
