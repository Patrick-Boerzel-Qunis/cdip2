"""
Contains global settings and system functions.
"""
import time
from warnings import warn, simplefilter
import pytz
import datetime

from ..core.exceptions import InvalidCommandException


_disable_msgs = False


def set_setting(setting: str, val: object) -> None:
    """
    Sets a global preference. Available Settings:

    "disable_msgs" (True, False): Disables all console
        outputs in MatrixMatcher via the message_out function.

    :param setting: Unique label of the preference.
    :param val: Desired value of the preference.
    """
    global _disable_msgs

    if setting == 'disable_msgs':
        _disable_msgs = val
    else:
        raise InvalidCommandException(
            "setting", ["disable_msgs"]
        )


def get_setting(setting: str) -> bool:
    """
    Returns a global preference. Available Settings:

    "disable_msgs" (True, False): Disables all console
        outputs in MatrixMatcher via the message_out function.

    :param setting: Unique label of the preference.
    """

    if setting == 'disable_msgs':
        return _disable_msgs
    else:
        raise InvalidCommandException(
            "setting", ["disable_msgs"]
        )


# noinspection PyBroadException
def message_out(msg: str,
                filler: [str, int] = " ",
                length: int = 60) -> None:
    """
    Prints a given string message to console with timestamp.

    :param msg: Message to print.
    :param filler: Character to fill the formatted string with. If an integer is passed,
        it is converted into a specified character.
    :param length: Length of the formatted string.
    """

    try:
        if isinstance(filler, int):
            fillers = [
                '.', '-', '+', '#', '*', '\'', '=', ')', '(', '/', '&', '%',
                '§', '\"', '!', '؋', '$', 'ƒ', '₼', 'л', '៛', '¥', '₡', '₱',
                '€', '£', '¢', '₹', '﷼', '₪', 'д', '°', ',', '?', '§', '<', '>',
                '~', '^'
            ]

            filler = fillers[filler % len(fillers)]

        msg = ("{:" + filler + "^" + str(length) + "}").format(f" {msg} ")
    except Exception:
        ...

    if not _disable_msgs:
        tz = pytz.timezone('Europe/Berlin')
        print("[" + datetime.datetime.now(tz=tz).strftime(
            "%H:%M:%S") + "] " + msg)


def measure_time(func: callable, *args, **kwargs) -> object:
    """
    Measures the runtime of a given function in milliseconds.
    The measurement is printed to the console.

    :param func: input function to execute. The runtime of
        the execution is measured.
    :param args: Function's positional arguments
    :param kwargs: Function's keyword arguments
    :return: Output of the passed function with arguments.
    """
    if not _disable_msgs:
        t0 = time.perf_counter()
        out = func(*args, **kwargs)
        t1 = time.perf_counter()
        message_out(
            '<<Duration: %f ms>>' % ((t1 - t0) * 1000)
        )
    else:
        out = func(*args, **kwargs)
    return out


# Deprecation warnings
##########################

def deprecation_warning_alias(new_name: str):
    """
    Decorator to use for deprecated function/method names.
    :param new_name: New name to use for the given function or method.
    """

    # noinspection PyDeprecation
    def decorator(function):
        def wrapper(*args, **kwargs):
            simplefilter('always', DeprecationWarning)
            warn(
                "The name of this function is deprecated "
                "and will be removed. "
                f"Please use name \'{new_name}\' instead.",
                DeprecationWarning,
                stacklevel=2
            )

            result = function(*args, **kwargs)

            return result
        return wrapper
    return decorator


def deprecation_warning_deletion(msg: str):
    """
    Decorator to use for deprecated function names.
    :param msg: Additional message to print with warning.
    """

    # noinspection PyDeprecation
    def decorator(function):
        def wrapper(*args, **kwargs):
            simplefilter('always', DeprecationWarning)
            warn(
                "This function is deprecated "
                f"and will be removed. {msg}",
                DeprecationWarning,
                stacklevel=2
            )

            result = function(*args, **kwargs)

            return result
        return wrapper
    return decorator


#############
# DEPRECATION
#############

@deprecation_warning_alias("set_setting")
def setSetting(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'set_setting'.
    """
    return set_setting(*args, **kwargs)


@deprecation_warning_alias("measure_time")
def measureTime(*args, **kwargs):
    """
    Deprecated function name.
    Please refer to name 'measure_time'.
    """
    return measure_time(*args, **kwargs)
